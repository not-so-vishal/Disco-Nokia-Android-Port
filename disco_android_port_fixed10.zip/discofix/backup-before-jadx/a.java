/*
 * Decompiled with CFR 0.152.
 */
package com.nokia.mid.appl.disco;

import com.nokia.mid.appl.disco.b;

public class a {
    int z;
    int y;
    int s;
    int o;
    int q;
    int m;
    int w;
    int l;
    int f;
    int u;
    int d;
    int p;
    int r;
    int k;
    boolean n;
    boolean e;
    boolean j;
    int v;
    int t;
    int[] a;
    int c;
    int[] i = new int[120];
    int A;
    long x;
    long g;
    long h;
    int b;

    public a() {
        this.a = new int[10];
        this.g(0);
    }

    public void g(int n) {
        this.e = false;
        this.j = false;
        this.A = 0;
        this.w = 0;
        this.l = 0;
        this.u = 0;
        this.d = 0;
        this.b = 0;
        this.v = 0;
        this.x = 0L;
        this.g = 0L;
        this.h = 1L;
        this.t = 0;
        int n2 = 0;
        while (n2 < this.a.length) {
            this.a[n2] = 0;
            ++n2;
        }
        this.c = 0;
        switch (n) {
            default: {
                this.z = Integer.MAX_VALUE;
                break;
            }
            case 1: {
                this.z = 0x1770000;
                break;
            }
            case 2: {
                this.z = 0xFA0000;
            }
        }
        this.y = 49152;
        this.o = this.s = 384;
        this.r = 0;
        this.p = 491520;
        this.m = 0;
        this.f = 0;
        this.q = 0;
        this.k = 0;
        this.n = false;
    }

    public boolean r() {
        return this.e;
    }

    public boolean c() {
        return this.j;
    }

    public void c(int n) {
        this.q = n;
    }

    public int v() {
        return this.q;
    }

    public boolean u() {
        switch (this.q) {
            case 0: {
                if (this.s > 1920) {
                    return false;
                }
            }
            case 1: {
                if (this.s > 5760) {
                    return false;
                }
            }
            case 2: {
                if (this.s <= 10240) break;
                return false;
            }
        }
        return true;
    }

    public void d(int n) {
        this.j = true;
        this.z += n << 14;
        this.k += 150 * n / 100 << 14;
    }

    public boolean e() {
        return this.n;
    }

    public void a(boolean bl) {
        this.n = bl;
    }

    public boolean p() {
        return this.f != 0;
    }

    public int i() {
        return this.m;
    }

    public boolean g() {
        return this.d != 0;
    }

    public int a() {
        return this.u;
    }

    public int l() {
        return this.w / 1000;
    }

    public int j() {
        return this.l / 1000;
    }

    public void m() {
        this.t = 0;
        this.m = 0;
        this.f = 0;
        this.w = 0;
        this.u = 0;
        this.d = 0;
    }

    public boolean t() {
        return this.r - this.y > 49152;
    }

    public boolean o() {
        return this.o - this.s > 256;
    }

    public void a(int n) {
        int n2;
        this.v -= n;
        if (this.v < 0) {
            this.v = 0;
        } else if (this.v > 75000) {
            this.v = 75000;
        }
        if (this.m >= 1 && this.t > 0) {
            this.w = 0;
            this.t -= n;
            if (this.t <= 0) {
                this.t = 0;
                this.m = 0;
                this.f = 0;
                this.u = 0;
                this.d = 0;
            }
        } else {
            this.w += n;
        }
        this.l += n;
        this.r = 0;
        int n3 = 0;
        while (n3 < this.A) {
            n2 = n3 * 3;
            this.r += this.i[n2 + 2] << 7;
            ++n3;
        }
        this.r += this.f << 7;
        this.r += this.d << 7;
        this.r += this.p;
        this.r += this.b;
        if (this.n) {
            this.r += 160 * (this.s >> 7) / 100 << 14;
        }
        n2 = 0;
        switch (this.q) {
            case 0: {
                if (this.s <= 1920) break;
                n2 = 1;
                break;
            }
            case 1: {
                if (this.s <= 5760) break;
                n2 = 1;
                break;
            }
            case 2: {
                if (this.s <= 10240) break;
                n2 = 1;
                break;
            }
            case 3: {
                if (this.s <= 25600) break;
                n2 = 1;
            }
        }
        if (this.r > this.y + 1920) {
            this.y += 51200 * n / 1000;
            if (n2 == 0) {
                this.p += 1000 * n / 1000;
            }
        } else if (this.r <= this.y - 1920) {
            this.y -= 51200 * n / 1000;
            if (this.r > 0) {
                this.p -= 1000 * n / 1000;
            }
        }
        if (n2 != 0) {
            this.p -= 1000 * n / 1000;
        }
        int n4 = this.y;
        n4 = this.s != 0 ? (n4 /= this.s) : 0;
        this.a[this.c] = n4;
        int n5 = 0;
        int n6 = 0;
        while (n6 < this.a.length) {
            n5 += this.a[n6];
            ++n6;
        }
        ++this.c;
        this.c %= this.a.length;
        if ((n5 /= this.a.length) - n4 <= 2 && n5 - n4 >= -2) {
            this.p -= 1000 * n / 1000;
        }
        if (n4 > 160) {
            this.s += 55 * n / 1000;
        } else if (n4 <= 112) {
            this.s -= 768 * n / 1000;
            this.o -= 768 * n / 1000;
            if (this.o < 0) {
                this.o = 0;
            }
            if (this.s < 0) {
                this.s = 0;
            }
        }
        if (this.o > this.s) {
            this.s += 440 * n / 1000;
        } else {
            this.o = this.s;
        }
        if (this.s >= 38528) {
            this.o = this.s = 38528;
        }
        int n7 = 163840 * n / 1000;
        if (this.k > 0) {
            this.k -= 84480 * n / 1000;
            if (this.k < 0) {
                this.k = 0;
            }
            n7 += 84480 * n / 1000;
        }
        int n8 = 153;
        if (this.n) {
            n8 = -48;
        }
        this.z += n8 * this.s / 1000 * n;
        this.z -= n7;
        this.x += (long)(this.d() * n);
        this.g += (long)(this.b() * n);
        this.h += (long)n;
    }

    public void f(int n) {
        this.b = n << 7;
    }

    public int s() {
        return this.z >> 14;
    }

    public int d() {
        return this.y >> 14;
    }

    public int b() {
        return this.s >> 7;
    }

    public int q() {
        return this.k >> 14;
    }

    public boolean a(byte by, byte by2) {
        if (by >= 51 && by <= 69) {
            return by == this.m;
        }
        int n = 0;
        while (n < this.A * 3) {
            if (this.i[n] == by && this.i[n + 1] >= by2) {
                return true;
            }
            n += 3;
        }
        return false;
    }

    public void a(int n, int n2) {
        this.t = 30000;
        this.m = n;
        this.f = n2;
    }

    public void a(byte by, byte by2, int n, int n2) {
        this.z += n << 14;
        this.l = 0;
        if (by >= 51 && by <= 69) {
            this.t = 30000;
            this.m = by;
            this.f = n2;
            if (by >= 51 && by < 54) {
                this.f = com.nokia.mid.appl.disco.b.g(this.f / 2, this.f);
            }
        } else if (by >= 71 && by <= 99) {
            this.e = true;
            if (by == 71) {
                int n3 = 37000 - this.v;
                if (n3 < 3700) {
                    n3 = 3700;
                }
                n3 = n3 * 40 / 37000;
                this.o += n3 << 7;
                this.v += 11000;
            } else if (by == 72) {
                int n4 = 37000 - this.v;
                if (n4 < 3700) {
                    n4 = 3700;
                }
                n4 = n4 * 80 / 37000;
                this.o += n4 << 7;
                this.v += 15000;
            } else if (by == 73) {
                int n5 = 37000 - this.v;
                if (n5 < 740) {
                    n5 = 740;
                }
                if ((n5 = n5 * (40 * (this.s >> 7) / 100) / 37000) > 20) {
                    n5 = 20;
                }
                this.o += n5 << 7;
                this.v += 8000;
            } else if (by == 74) {
                this.t = 30000;
                this.m = 51 + com.nokia.mid.appl.disco.b.g(3, 6);
                this.f = 1;
                this.u = com.nokia.mid.appl.disco.b.g(0, 3);
                this.d = com.nokia.mid.appl.disco.b.g(8000, 16000);
            }
        } else if (by >= 1 && by <= 29 || by >= 31 && by <= 49) {
            System.out.println("b1");
            boolean bl = false;
            int n6 = 0;
            while (n6 < this.A * 3) {
                if (this.i[n6] == by) {
                    this.i[n6 + 1] = by2;
                    this.i[n6 + 2] = n2;
                    bl = true;
                    break;
                }
                n6 += 3;
            }
            System.out.println("b2");
            if (!bl) {
                this.i[this.A * 3] = by;
                this.i[this.A * 3 + 1] = by2;
                this.i[this.A * 3 + 2] = n2;
                ++this.A;
            }
            System.out.println("b3");
        }
    }

    public int h() {
        return this.A;
    }

    public int b(int n) {
        int n2 = this.i[n * 3];
        int n3 = n * 3 + 1;
        this.i[n3] = this.i[n3] - 1;
        if (this.i[n * 3 + 1] <= 0) {
            int n4 = n * 3;
            int n5 = n;
            while (n5 < this.A - 1) {
                int n6 = 0;
                while (n6 < 3) {
                    this.i[n4 + n6] = this.i[n4 + n6 + 3];
                    ++n6;
                }
                ++n5;
                n4 += 3;
            }
            --this.A;
        }
        return n2;
    }

    public int e(int n) {
        int n2 = 0;
        int n3 = 0;
        while (n3 < this.A) {
            if (this.i[n2] == n) {
                return this.i[n2 + 1];
            }
            ++n3;
            n2 += 3;
        }
        return -1;
    }

    public int k() {
        return (int)(this.h / 1000L);
    }

    public int f() {
        return (int)(this.x / this.h);
    }

    public int n() {
        return (int)(this.g / this.h);
    }
}

