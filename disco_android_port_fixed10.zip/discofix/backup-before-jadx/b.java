/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nokia.mid.ui.DirectGraphics
 *  com.nokia.mid.ui.DirectUtils
 *  javax.microedition.lcdui.Alert
 *  javax.microedition.lcdui.Command
 *  javax.microedition.lcdui.CommandListener
 *  javax.microedition.lcdui.Display
 *  javax.microedition.lcdui.Displayable
 *  javax.microedition.lcdui.Font
 *  javax.microedition.lcdui.Form
 *  javax.microedition.lcdui.Graphics
 *  javax.microedition.lcdui.Image
 *  javax.microedition.lcdui.Item
 *  javax.microedition.lcdui.List
 *  javax.microedition.lcdui.StringItem
 *  javax.microedition.midlet.MIDlet
 *  javax.microedition.rms.RecordStore
 */
package com.nokia.mid.appl.disco;

import com.nokia.mid.appl.disco.a;
import com.nokia.mid.appl.disco.c;
import com.nokia.mid.appl.disco.e;
import com.nokia.mid.ui.DirectGraphics;
import com.nokia.mid.ui.DirectUtils;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.Random;
import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.Item;
import javax.microedition.lcdui.List;
import javax.microedition.lcdui.StringItem;
import javax.microedition.midlet.MIDlet;
import javax.microedition.rms.RecordStore;

public class b
extends e
implements CommandListener {
    private boolean bc = false;
    private boolean O;
    private int l;
    private Image N;
    private Image ba;
    private Image bm;
    private Image c;
    private Image aH;
    private int R;
    private Image aZ;
    private Image bB;
    private Image r;
    private Image Y;
    private Image[] C;
    private Font ab;
    private Font aW;
    private int bu;
    private byte[] aM;
    private String A;
    private int o;
    private byte aV;
    private byte bh;
    private int at;
    private int m;
    private int Q;
    private int a;
    private int ar;
    private byte[][] B;
    private int k;
    private int bD;
    private int L = 100;
    private int X;
    private int az;
    private int bf;
    private int G;
    private int[] u;
    private boolean bd;
    private boolean aL;
    private static Random aC;
    private List bJ;
    private Alert s;
    private Form ae;
    private Display v;
    private a bs;
    private int[] T;
    private int[] bC;
    private byte[] y;
    private int[] bv;
    private int[] aq;
    private byte[] aj;
    private int[] aw;
    private int[] aD;
    private byte[] P;
    private byte[] bG;
    private int[] aT;
    private byte[] by;
    private int[] bN;
    private int ax;
    private int bA;
    private int d;
    private boolean an = false;
    private int Z;
    private int bt;
    private int au;
    private int aU;
    private int e;
    private int aE;
    private int K;
    private Command bF;
    private Command aJ;
    private int bn;
    private byte[] p;
    private int aF;
    private int as;
    private int aS;
    private int[] bH;
    private boolean ag = false;
    private int aX = 256;
    private int al;
    private int U;
    private int[] aa;
    private int[] aB;
    private boolean ap = false;
    private int[] F;
    private int[] ad;
    private String af;
    private boolean aO = false;
    private int[] bo = new int[]{6, 72, 20, 77, 64, 77, 77, 72};
    private int[] bj = new int[]{34, 35, 36, 37, 38, 39};
    private int[] t = new int[]{83, 93, 97, 98, 99, 100, 84, 85, 86, 87, 88, 89, 90, 91, 92, 94, 95, 96};
    private String[] bE;
    private int[] bz = new int[]{82, 115, 10, 1, 18, 112};
    private int[] aN = new int[]{61, 60, 63, 62, 65, 64, 67, 66, 69, 68, 71, 70, 73, 72, 75, 74};
    private int[] H = new int[]{12, 11, 14, 13};
    private int[] am = new int[]{117, 116, 119, 118, 121, 120, 123, 122};
    private int[] bg = new int[]{3, 2, 5, 4, 7, 6, 9, 8};
    private int[] ak = new int[]{76, 77, 78, 79, 80, 81};
    private int[] br = new int[]{124, 125, 127, 126};
    private int[] D = new int[]{15, 16};
    private int[] J = new int[]{56, 57, 58};
    private byte[] b;
    private byte[] bb;
    private byte[] h;
    private byte[] bO;
    private byte[] ai;
    private String[] bw;
    private String[] aR;
    private String[] bi;
    private String[] w;
    private byte[] be;
    private int[] bp;
    private byte[] ac;
    private int[] aI;
    private int aP;
    private int I;
    private boolean av;

    public void d(int n) {
        if (this.aP < n) {
            this.aP = n;
        }
        this.I = n;
    }

    public void b() throws Exception {
        super.b();
        aC = new Random(System.currentTimeMillis());
        this.C();
        this.af = com.nokia.mid.appl.disco.c.a(29);
        this.s();
        this.bs = new a();
        this.F = new int[12];
        int n = 0;
        while (n < this.F.length) {
            this.F[n] = n;
            ++n;
        }
        int n2 = 0;
        while (n2 < this.F.length) {
            int n3 = this.F[n2];
            int n4 = aC.nextInt() % this.F.length;
            if (n4 < 0) {
                n4 = -n4;
            }
            this.F[n2] = this.F[n4];
            this.F[n4] = n3;
            ++n2;
        }
        this.aM = new byte[36];
        this.aa = new int[10];
        this.u = new int[80];
        this.bN = new int[10];
        this.bC = new int[this.T.length];
        this.aq = new int[this.bv.length];
        this.aD = new int[this.aw.length];
        this.a(this.bC, this.T, this.y, 70, 110);
        this.a(this.aq, this.bv, this.aj, 70, 110);
        this.a(this.aD, this.aw, this.bG, 90, 120);
        this.bC[6] = 0;
        this.bC[7] = 0;
        this.bC[8] = 0;
        this.v = Display.getDisplay((MIDlet)this.bq);
        this.s = new Alert("");
        this.s.setTitle("");
        this.bJ = new List("", 3);
        this.bJ.setCommandListener((CommandListener)this);
        this.ae = new Form("");
        this.ae.setCommandListener((CommandListener)this);
        this.bF = new Command(com.nokia.mid.appl.disco.c.a(55), 4, 1);
        this.aJ = new Command(com.nokia.mid.appl.disco.c.a(17), 2, 1);
        this.ab = Font.getFont((int)64, (int)0, (int)0);
        this.aW = Font.getFont((int)64, (int)0, (int)8);
        this.e();
    }

    private void a(int[] nArray, int[] nArray2, byte[] byArray, int n, int n2) {
        byte by = -1;
        int n3 = 0;
        int n4 = 0;
        while (n4 < nArray2.length) {
            n3 = byArray[n4 * 2] == by ? n2 * n3 / 100 : 1024 * n / 100;
            by = byArray[n4 * 2];
            nArray[n4] = nArray2[n4] * n3 / 500;
            ++n4;
        }
    }

    public void commandAction(Command command, Displayable displayable) {
        super.commandAction(command, displayable);
        if (displayable == this.bJ && command == List.SELECT_COMMAND) {
            switch (this.bN[this.ax - 1]) {
                case 1: 
                case 2: 
                case 3: 
                case 4: 
                case 5: {
                    this.j(1);
                    break;
                }
            }
        } else if (displayable == this.bJ || displayable == this.ae) {
            switch (this.bN[this.ax - 1]) {
                case 1: 
                case 2: 
                case 3: 
                case 4: 
                case 5: {
                    if (command != this.aJ) break;
                    this.j(0);
                    break;
                }
                case 7: 
                case 15: {
                    if (command != this.bF && command != this.aJ) break;
                    this.j(0);
                    break;
                }
                case 16: {
                    if (command != this.bF) break;
                    this.j(1);
                    break;
                }
                case 6: 
                case 13: {
                    if (command == this.aJ) {
                        this.j(0);
                        break;
                    }
                    if (command != this.bF) break;
                    this.j(1);
                    break;
                }
                case 14: {
                    if (command != this.bF) break;
                    this.j(1);
                    break;
                }
            }
        }
    }

    private void j(int n) {
        if (n == 0) {
            this.p();
            if (this.bN[this.ax - 1] == 0) {
                if (this.az > 5000 && this.aF < 0) {
                    this.A();
                }
                this.v.setCurrent((Displayable)this);
                this.aU = 1;
            }
        } else if (n == 1) {
            int n2 = this.bN[this.ax - 1];
            switch (n2) {
                case 0: {
                    this.bA = 0;
                    this.j();
                    this.aU = 2;
                    break;
                }
                case 1: {
                    this.bA = this.bJ.getSelectedIndex();
                    this.d = 0;
                    int n3 = this.bJ.getSelectedIndex();
                    switch (n3) {
                        case 0: {
                            this.n();
                            break;
                        }
                        case 1: {
                            this.y();
                            break;
                        }
                        case 2: {
                            this.v();
                            break;
                        }
                        case 3: {
                            this.c();
                            break;
                        }
                        case 4: {
                            this.x();
                            break;
                        }
                        case 5: {
                            this.B();
                        }
                    }
                    break;
                }
                case 2: {
                    this.d = this.bJ.getSelectedIndex();
                    if (!this.a(this.bw, this.am, this.T, this.ai, this.y, this.bC, com.nokia.mid.appl.disco.c.a(115))) break;
                    this.bN[this.ax++] = 13;
                    break;
                }
                case 3: {
                    this.d = this.bJ.getSelectedIndex();
                    if (!this.a(this.aR, this.H, this.bv, this.bO, this.aj, this.aq, com.nokia.mid.appl.disco.c.a(10))) break;
                    this.bN[this.ax++] = 13;
                    break;
                }
                case 4: {
                    this.d = this.bJ.getSelectedIndex();
                    if (!this.a(this.w, this.aN, this.aw, this.h, this.bG, this.aD, com.nokia.mid.appl.disco.c.a(82))) break;
                    this.bN[this.ax++] = 13;
                    break;
                }
                case 5: {
                    this.d = this.bJ.getSelectedIndex();
                    if (!this.a(this.bi, this.bg, this.aT, this.bb, this.by, null, com.nokia.mid.appl.disco.c.a(1))) break;
                    this.bN[this.ax++] = 13;
                    break;
                }
                case 6: {
                    this.bs.d(1000);
                    this.p();
                    this.s.setString(com.nokia.mid.appl.disco.c.a(21));
                    this.s.setTimeout(1500);
                    this.aO = true;
                    this.v.setCurrent(this.s, (Displayable)this.bJ);
                    break;
                }
                case 7: {
                    this.p();
                    break;
                }
                case 14: {
                    this.p();
                    this.aU = 1;
                    this.v.setCurrent((Displayable)this);
                    break;
                }
                case 16: {
                    ++this.I;
                    if (this.I > 2) {
                        this.bc = true;
                        this.O = false;
                    } else {
                        if (this.I > com.nokia.mid.appl.disco.e.aY[0]) {
                            com.nokia.mid.appl.disco.e.aY[0] = (byte)this.I;
                        }
                        this.k();
                        this.h(this.I, 1);
                    }
                    this.v.setCurrent((Displayable)this);
                    break;
                }
                case 15: {
                    this.p();
                    this.aU = 1;
                    this.v.setCurrent((Displayable)this);
                    break;
                }
                case 13: {
                    System.out.println("a1");
                    this.bs.a(this.aV, this.bh, this.o, this.at);
                    System.out.println("a2");
                    if (this.aV == 31) {
                        this.R = this.bh;
                    }
                    if (this.aV == 2) {
                        if (this.bh == 1) {
                            this.bs.c(1);
                        } else if (this.bh == 2) {
                            this.bs.c(2);
                        } else if (this.bh == 3) {
                            this.bs.c(3);
                        }
                    }
                    System.out.println("a3");
                    this.p();
                    System.out.println("a4");
                    if (this.aV >= 51 && this.aV <= 69) {
                        this.s.setString(com.nokia.mid.appl.disco.c.a(33));
                    } else if (this.aV == 74) {
                        this.s.setString(com.nokia.mid.appl.disco.c.a(this.J[this.bs.a()]));
                    } else {
                        this.s.setString(com.nokia.mid.appl.disco.c.a(101));
                    }
                    System.out.println("a5");
                    this.s.setTimeout(1500);
                    this.aO = true;
                    this.v.setCurrent(this.s, (Displayable)this.bJ);
                }
            }
        }
    }

    private void j() {
        int n;
        while (this.bJ.size() > 0) {
            this.bJ.delete(0);
        }
        this.bJ.addCommand(this.aJ);
        this.bJ.setTitle(com.nokia.mid.appl.disco.c.a(28));
        if (this.bE == null) {
            this.bE = new String[this.bz.length];
            n = 0;
            while (n < this.bE.length) {
                this.bE[n] = com.nokia.mid.appl.disco.c.a(this.bz[n]);
                ++n;
            }
        }
        n = 0;
        while (n < this.bE.length) {
            this.bJ.append(this.bE[n], null);
            ++n;
        }
        this.bJ.setSelectedIndex(this.bA, true);
        this.aO = true;
        this.v.setCurrent((Displayable)this.bJ);
        this.bN[this.ax++] = 1;
        this.aU = 2;
    }

    private void y() {
        if (this.bw == null) {
            this.bw = new String[this.T.length];
            this.a(this.bw, this.am, this.T, this.ai, this.y, true);
        }
        this.a(this.bw, this.T, this.ai, this.y, com.nokia.mid.appl.disco.c.a(115));
        this.bN[this.ax++] = 2;
    }

    private void v() {
        if (this.aR == null) {
            this.aR = new String[this.bv.length];
            this.a(this.aR, this.H, this.bv, this.bO, this.aj, true);
        }
        this.a(this.aR, this.bv, this.bO, this.aj, com.nokia.mid.appl.disco.c.a(10));
        this.bN[this.ax++] = 3;
    }

    private void c() {
        if (this.bi == null) {
            this.bi = new String[this.aT.length];
            this.a(this.bi, this.bg, this.aT, this.bb, this.by, false);
        }
        this.a(this.bi, this.aT, this.bb, this.by, com.nokia.mid.appl.disco.c.a(1));
        this.bN[this.ax++] = 5;
    }

    private void n() {
        if (this.w == null) {
            this.w = new String[this.aw.length];
            this.a(this.w, this.aN, this.aw, this.h, this.bG, false);
        }
        this.a(this.w, this.aw, this.h, this.bG, com.nokia.mid.appl.disco.c.a(82));
        this.bN[this.ax++] = 4;
    }

    private void s() {
        this.bw = new String[this.T.length];
        this.a(this.bw, this.am, this.T, this.ai, this.y, true);
    }

    private void a(String[] stringArray, int[] nArray, int[] nArray2, byte[] byArray, byte[] byArray2, boolean bl) {
        byte by = -1;
        int n = -1;
        int n2 = 0;
        int n3 = 0;
        while (n3 < nArray2.length) {
            if (by != byArray2[n3 * 2]) {
                ++n;
                n2 = 1;
            } else {
                ++n2;
            }
            by = byArray2[n3 * 2];
            stringArray[n3] = bl ? (n2 != 1 ? com.nokia.mid.appl.disco.c.a(nArray[n * 2], new String[]{com.nokia.mid.appl.disco.c.a(this.bj[n2 - 1]), com.nokia.mid.appl.disco.c.a(this.t[byArray[n3]])}) : com.nokia.mid.appl.disco.c.a(nArray[n * 2], new String[]{"", com.nokia.mid.appl.disco.c.a(this.t[byArray[n3]])})) : com.nokia.mid.appl.disco.c.a(nArray[n * 2], new String[]{com.nokia.mid.appl.disco.c.a(this.t[byArray[n3]])});
            ++n3;
        }
    }

    private void a(String[] stringArray, int[] nArray, byte[] byArray, byte[] byArray2, String string) {
        while (this.bJ.size() > 0) {
            this.bJ.delete(0);
        }
        this.bJ.addCommand(this.aJ);
        this.bJ.setTitle(string);
        int n = 0;
        int n2 = this.bs.s();
        byte by = -1;
        int n3 = -1;
        int n4 = 0;
        int n5 = 0;
        while (n5 < nArray.length) {
            if (by != byArray2[n5 * 2]) {
                ++n3;
                n4 = 1;
            } else {
                ++n4;
            }
            by = byArray2[n5 * 2];
            if (!this.bs.a(byArray2[n5 * 2], byArray2[n5 * 2 + 1])) {
                if (n2 - nArray[n5] >= 0) {
                    this.bJ.append(stringArray[n5], null);
                } else if (n2 - nArray[n5] >= -700 && ++n < 3) {
                    this.bJ.append(stringArray[n5], null);
                }
            }
            ++n5;
        }
        if (this.d >= this.bJ.size()) {
            this.d = this.bJ.size() - 1;
        }
        if (this.bJ.size() > 0) {
            int n6 = this.d;
            if (n6 >= this.bJ.size()) {
                n6 = 0;
            }
            this.bJ.setSelectedIndex(n6, true);
        }
        this.aO = true;
        this.v.setCurrent((Displayable)this.bJ);
    }

    private boolean a(String[] stringArray, int[] nArray, int[] nArray2, byte[] byArray, byte[] byArray2, int[] nArray3, String string) {
        int n = 0;
        int n2 = 0;
        int n3 = this.bs.s();
        byte by = -1;
        int n4 = -1;
        int n5 = 0;
        int n6 = 0;
        while (n6 < nArray2.length) {
            if (by != byArray2[n6 * 2]) {
                ++n4;
                n5 = 1;
            } else {
                ++n5;
            }
            by = byArray2[n6 * 2];
            if (!this.bs.a(byArray2[n6 * 2], byArray2[n6 * 2 + 1])) {
                if (n3 - nArray2[n6] > 0) {
                    if (byArray2[n6 * 2] >= 51 && byArray2[n6 * 2] <= 69 && n2 == this.bJ.getSelectedIndex()) {
                        byte by2 = byArray2[n6 * 2 + 1];
                        int n7 = this.bs.e(31);
                        int n8 = this.bs.e(32);
                        boolean bl = false;
                        int n9 = -1;
                        int n10 = -1;
                        switch (by2) {
                            default: {
                                break;
                            }
                            case 2: {
                                n9 = 1;
                                n10 = 1;
                                break;
                            }
                            case 3: {
                                n9 = 2;
                                n10 = 2;
                                break;
                            }
                            case 4: {
                                n9 = 3;
                                n10 = 3;
                            }
                        }
                        if (n8 < n9) {
                            bl = true;
                            this.s.setString(com.nokia.mid.appl.disco.c.a(80));
                        } else if (n7 < n10) {
                            bl = true;
                            this.s.setString(com.nokia.mid.appl.disco.c.a(81));
                        }
                        if (bl) {
                            this.s.setTimeout(1500);
                            this.aO = true;
                            this.v.setCurrent(this.s, (Displayable)this.bJ);
                            return false;
                        }
                    }
                    if (n2 == this.bJ.getSelectedIndex()) {
                        this.A = stringArray[n6];
                        this.o = nArray2[n6];
                        this.aV = byArray2[n6 * 2];
                        this.bh = byArray2[n6 * 2 + 1];
                        this.at = nArray3 != null ? nArray3[n6] : 0;
                        while (this.ae.size() > 0) {
                            this.ae.delete(0);
                        }
                        this.ae.setTitle(this.A);
                        this.ae.append(com.nokia.mid.appl.disco.c.a(nArray[n4 * 2 + 1]));
                        this.ae.addCommand(this.aJ);
                        this.ae.addCommand(this.bF);
                        this.aO = true;
                        this.v.setCurrent((Displayable)this.ae);
                        break;
                    }
                    ++n2;
                } else if (n3 - nArray2[n6] >= -700 && ++n < 3) {
                    if (n2 == this.bJ.getSelectedIndex()) {
                        this.s.setString(com.nokia.mid.appl.disco.c.a(22));
                        this.s.setTimeout(1500);
                        this.aO = true;
                        this.v.setCurrent(this.s, (Displayable)this.bJ);
                        return false;
                    }
                    ++n2;
                }
            }
            ++n6;
        }
        return true;
    }

    private void x() {
        if (this.bs.q() == 0) {
            while (this.ae.size() > 0) {
                this.ae.delete(0);
            }
            this.ae.setTitle(com.nokia.mid.appl.disco.c.a(18));
            this.ae.append(com.nokia.mid.appl.disco.c.a(19));
            this.ae.addCommand(this.aJ);
            this.ae.addCommand(this.bF);
            this.aO = true;
            this.v.setCurrent((Displayable)this.ae);
            this.bN[this.ax++] = 6;
        } else {
            this.s.setString(com.nokia.mid.appl.disco.c.a(20));
            this.s.setTimeout(3000);
            this.aO = true;
            this.v.setCurrent((Displayable)this.s);
        }
    }

    private void B() {
        int n;
        while (this.ae.size() > 0) {
            this.ae.delete(0);
        }
        this.ae.setTitle(com.nokia.mid.appl.disco.c.a(112));
        int n2 = (900 - this.bs.k()) / 30 + 1;
        if (n2 < 0) {
            n2 = 0;
        }
        if ((n = 100 * this.bs.f() / 150) < 0) {
            n = 0;
        } else if (n > 100) {
            n = 100;
        }
        int n3 = this.bs.s() + this.bs.n() * 10 + this.bs.f() * 100;
        StringItem stringItem = new StringItem(null, com.nokia.mid.appl.disco.c.a(113, new String[]{new String("" + n2)}));
        StringItem stringItem2 = new StringItem(null, com.nokia.mid.appl.disco.c.a(50, new String[]{new String("" + this.bs.s())}));
        StringItem stringItem3 = new StringItem(null, com.nokia.mid.appl.disco.c.a(59, new String[]{"" + this.bs.n() * 10}));
        StringItem stringItem4 = new StringItem(null, com.nokia.mid.appl.disco.c.a(51, new String[]{"" + n * 100}));
        StringItem stringItem5 = new StringItem(null, com.nokia.mid.appl.disco.c.a(114, new String[]{new String("" + n3)}));
        StringItem stringItem6 = new StringItem(null, com.nokia.mid.appl.disco.c.a(48, new String[]{new String("" + this.bs.q())}));
        this.ae.append((Item)stringItem);
        this.ae.append("\n");
        this.ae.append((Item)stringItem2);
        this.ae.append("\n");
        this.ae.append((Item)stringItem3);
        this.ae.append("\n");
        this.ae.append((Item)stringItem4);
        this.ae.append("\n");
        this.ae.append((Item)stringItem5);
        this.ae.append("\n");
        this.ae.append((Item)stringItem6);
        this.ae.removeCommand(this.bF);
        this.ae.addCommand(this.aJ);
        this.aO = true;
        this.v.setCurrent((Displayable)this.ae);
        this.bN[this.ax++] = 7;
    }

    private void p() {
        this.ax -= 2;
        int n = this.bN[this.ax];
        switch (n) {
            case 0: {
                ++this.ax;
                break;
            }
            case 1: {
                this.j();
                break;
            }
            case 2: {
                this.y();
                break;
            }
            case 3: {
                this.v();
                break;
            }
            case 4: {
                this.n();
                break;
            }
            case 5: {
                this.c();
                break;
            }
            case 14: {
                break;
            }
        }
    }

    public boolean u() {
        return this.O;
    }

    public boolean f() {
        return this.bc;
    }

    public void f(int n, int n2) {
        if (this.aU == 0 || this.aU == 3 || this.aU == 4) {
            return;
        }
        switch (this.bN[this.ax - 1]) {
            case 0: {
                if (n2 == 8 || n == 53) {
                    this.bs.a(!this.bs.e());
                    break;
                }
                if (n != -6) break;
                this.j(1);
                break;
            }
        }
    }

    public void a() {
        this.av = false;
        this.h(this.I, 1);
        this.O = true;
        super.a();
    }

    public void h() {
        if (this.av) {
            this.h(this.I, 1);
        }
        super.h();
    }

    public void showNotify() {
        super.showNotify();
        this.an = true;
        this.aE = 0;
    }

    public void J() {
        this.z();
        this.bm = null;
        this.ba = null;
        this.c = null;
        this.aH = null;
        this.aZ = null;
        this.bB = null;
        this.r = null;
        this.Y = null;
        this.C = null;
        super.J();
    }

    public void l() {
    }

    private void g(Graphics graphics) {
        int n;
        int n2;
        int n3;
        int n4;
        int n5;
        int n6;
        int n7 = 7377646;
        n7 = 2239591;
        graphics.setColor(n7 >> 16 & 0xFF, n7 >> 8 & 0xFF, n7 & 0xFF);
        graphics.fillRect(0, 11, 51, 69);
        n7 = 725306;
        graphics.setColor(n7 >> 16 & 0xFF, n7 >> 8 & 0xFF, n7 & 0xFF);
        graphics.fillRect(51, 11, 77, 81);
        DirectGraphics directGraphics = DirectUtils.getDirectGraphics((Graphics)graphics);
        int n8 = this.bs.e(1);
        if (n8 > 0) {
            n6 = 2;
            n5 = 2;
            n4 = 130;
            if (n8 > 1 && n8 <= 3) {
                n6 = 7;
                n5 = 9;
                n4 = 123;
            } else if (n8 > 3) {
                n6 = 14;
                n5 = 15;
                n4 = 109;
            }
            n3 = 51 - n6;
            n2 = 39 - n5;
            while (n3 > -n6) {
                n = n2;
                while (n > -n5) {
                    graphics.setClip(n3, n, n6, n5);
                    graphics.drawImage(this.c, n3 - n4, n, 20);
                    n -= 15;
                }
                n3 -= 14;
                n2 += 7;
            }
            n3 = 51;
            n2 = 24;
            while (n3 < 128) {
                n = n2;
                while (n > -15) {
                    graphics.setClip(n3, n, n6, n5);
                    DirectGraphics directGraphics2 = DirectUtils.getDirectGraphics((Graphics)graphics);
                    directGraphics2.drawImage(this.c, n3 - (this.c.getWidth() - n4 - n6), n, 20, 8192);
                    n -= 15;
                }
                n3 += 14;
                n2 += 7;
            }
        }
        n6 = 22;
        n5 = this.ba.getHeight();
        n4 = 11;
        n3 = this.ba.getHeight() / 2;
        n2 = (128 - (51 - n4)) / n6;
        n = 51 - n4 - (n2 + 1) * n6;
        int n9 = 39 + (n2 + 1) * n5;
        int n10 = 0;
        int n11 = this.bs.v();
        if (n11 == 1) {
            n11 = 2;
        } else if (n11 > 1) {
            n11 = n11 * 2 - 1;
        }
        while (n < 128) {
            int n12 = n9;
            int n13 = n10 + n11;
            while (n12 < 128 + n5) {
                graphics.setClip(n, n12, n6, n5);
                graphics.drawImage(this.ba, n - n13 * n6, n12, 20);
                n12 += n5;
            }
            if (n11 != 2) {
                ++n10;
                n10 %= 2;
            }
            if ((n += n4 + 1) <= 51 - n4) {
                n9 -= n3;
                continue;
            }
            n9 += n3;
        }
    }

    private void a(String string, boolean bl) {
        this.aU = 2;
        this.bN[this.ax++] = 14;
        while (this.ae.size() > 0) {
            this.ae.delete(0);
        }
        this.ae.setTitle(com.nokia.mid.appl.disco.c.a(54));
        this.ae.append(string);
        this.ae.removeCommand(this.aJ);
        if (bl) {
            this.ae.addCommand(this.bF);
        } else {
            this.ae.removeCommand(this.bF);
        }
        this.aO = true;
        this.v.setCurrent((Displayable)this.ae);
    }

    public void a(int n, int n2) {
        this.aE += n;
        if (this.aE < 10) {
            return;
        }
        this.Z = n2;
        this.an = true;
        n = this.aE;
        if (n > 800) {
            n = 800;
        }
        this.aE = 0;
        switch (this.aU) {
            case 0: {
                ++this.bt;
                if (this.bt <= 0) break;
                if (this.au >= 0) {
                    if (this.I == 0) {
                        this.a(com.nokia.mid.appl.disco.c.a(42), false);
                    } else if (this.I == 1) {
                        this.a(com.nokia.mid.appl.disco.c.a(46), false);
                    } else if (this.I == 2) {
                        this.a(com.nokia.mid.appl.disco.c.a(44), false);
                    }
                    if (this.aR == null) {
                        this.aR = new String[this.bv.length];
                        this.a(this.aR, this.H, this.bv, this.bO, this.aj, true);
                    }
                    if (this.bm == null) {
                        this.i();
                    }
                    this.ae.addCommand(this.bF);
                }
                this.aE = 0;
                this.F();
                this.aU = this.e;
                break;
            }
            case 4: {
                boolean bl = false;
                String string = "";
                this.bu += n;
                if (this.bu > 5000) {
                    switch (this.I) {
                        case 0: {
                            string = com.nokia.mid.appl.disco.c.a(43);
                            bl = true;
                            break;
                        }
                        case 1: {
                            string = com.nokia.mid.appl.disco.c.a(45);
                            bl = true;
                            break;
                        }
                        case 2: {
                            string = com.nokia.mid.appl.disco.c.a(47);
                            bl = true;
                        }
                    }
                }
                if (bl) {
                    while (this.ae.size() > 0) {
                        this.ae.delete(0);
                    }
                    this.ae.setTitle(com.nokia.mid.appl.disco.c.a(25));
                    this.ae.append(string);
                    this.ae.removeCommand(this.aJ);
                    this.ae.addCommand(this.bF);
                    this.aO = true;
                    this.v.setCurrent((Displayable)this.ae);
                    this.bN[this.ax++] = 16;
                    this.aU = 2;
                    return;
                }
                ++this.X;
                this.j(n, n2);
                this.c(n);
                this.a(n);
                break;
            }
            case 1: {
                int n3;
                this.E = true;
                this.az += n;
                ++this.X;
                int n4 = this.bs.q();
                if (this.aU == 1) {
                    this.bs.a(n);
                }
                if (this.bs.s() <= 0 && this.bs.e()) {
                    this.bs.a(false);
                } else if (this.bs.s() <= 0 && !this.bs.e() || 900 - this.bs.k() < 0) {
                    this.K = 0;
                    this.aU = 3;
                } else {
                    int n5;
                    n3 = this.bs.b();
                    if (n3 == 0 && this.bf - this.G > 0) {
                        this.bf = 1;
                    } else if (n3 < 15) {
                        n5 = 1 + 3 * (n3 - 0) / 15;
                        if (this.bf - this.G < n5) {
                            this.m();
                        } else if (this.bf - this.G > n5 && this.bf > 1) {
                            --this.bf;
                            this.f(this.bf);
                        }
                        if (this.bf == 0) {
                            this.bf = 1;
                        }
                    } else if (n3 > 90) {
                        if (this.bf - this.G < 9) {
                            this.m();
                        } else if (this.bf - this.G > 9) {
                            --this.bf;
                            this.f(this.bf);
                        }
                    } else {
                        n5 = 3 + 6 * (n3 - 15) / 75;
                        if (this.bf - this.G < n5) {
                            this.m();
                        } else if (this.bf - this.G > n5) {
                            --this.bf;
                            this.f(this.bf);
                        }
                    }
                    this.j(n, n2);
                    this.c(n);
                    this.a(n);
                    if (n4 > 0 && this.bs.q() == 0) {
                        while (this.ae.size() > 0) {
                            this.ae.delete(0);
                        }
                        this.ae.setTitle(com.nokia.mid.appl.disco.c.a(25));
                        this.ae.append(com.nokia.mid.appl.disco.c.a(49));
                        this.ae.removeCommand(this.aJ);
                        this.ae.addCommand(this.bF);
                        this.aO = true;
                        this.v.setCurrent((Displayable)this.ae);
                        this.bN[this.ax++] = 15;
                        this.aU = 2;
                    } else if (this.I == 0 && this.bs.k() > 25 && !this.bs.r() && !this.aL) {
                        this.aL = true;
                        this.aS = 0;
                        while (this.ae.size() > 0) {
                            this.ae.delete(0);
                        }
                        this.ae.setTitle(com.nokia.mid.appl.disco.c.a(25));
                        this.ae.append(com.nokia.mid.appl.disco.c.a(31));
                        this.ae.removeCommand(this.aJ);
                        this.ae.addCommand(this.bF);
                        this.aO = true;
                        this.v.setCurrent((Displayable)this.ae);
                        this.bN[this.ax++] = 15;
                        this.aU = 2;
                    } else if (this.I == 0 && this.bs.s() < 400 && !this.bs.c() && !this.bd) {
                        this.bd = true;
                        this.aS = 0;
                        while (this.ae.size() > 0) {
                            this.ae.delete(0);
                        }
                        this.ae.setTitle(com.nokia.mid.appl.disco.c.a(25));
                        this.ae.append(com.nokia.mid.appl.disco.c.a(32));
                        this.ae.removeCommand(this.aJ);
                        this.ae.addCommand(this.bF);
                        this.aO = true;
                        this.v.setCurrent((Displayable)this.ae);
                        this.bN[this.ax++] = 15;
                        this.aU = 2;
                    } else if (this.aF < 0) {
                        this.aS += n;
                        if (this.aS >= 10000) {
                            n5 = com.nokia.mid.appl.disco.b.g(0, this.b.length);
                            this.h(this.b[n5]);
                        }
                    } else {
                        this.i(this.aF, n);
                    }
                }
                if (this.aU == 4) break;
                switch (this.I) {
                    case 0: {
                        if (this.bs.s() < 10000) break;
                        this.bu = 0;
                        this.bs.a(false);
                        this.aU = 4;
                        this.E = false;
                        n3 = this.bs.s() + this.bs.n() * 10 + this.bs.f() * 100;
                        String string = com.nokia.mid.appl.disco.c.a(41, new String[]{"" + (this.I + 1)});
                        com.nokia.mid.appl.disco.e.a(this.I, string, n3);
                        break;
                    }
                    case 1: {
                        if (100 * this.bs.d() / 150 < 100) break;
                        this.bu = 0;
                        this.bs.a(false);
                        this.aU = 4;
                        this.E = false;
                        n3 = this.bs.s() + this.bs.n() * 10 + this.bs.f() * 100;
                        String string = com.nokia.mid.appl.disco.c.a(41, new String[]{"" + (this.I + 1)});
                        com.nokia.mid.appl.disco.e.a(this.I, string, n3);
                        break;
                    }
                    case 2: {
                        if (this.bs.b() < 300) break;
                        this.bu = 0;
                        this.bs.a(false);
                        this.aU = 4;
                        this.E = false;
                        n3 = this.bs.s() + this.bs.n() * 10 + this.bs.f() * 100;
                        String string = com.nokia.mid.appl.disco.c.a(41, new String[]{"" + (this.I + 1)});
                        com.nokia.mid.appl.disco.e.a(this.I, string, n3);
                    }
                }
                break;
            }
            case 2: {
                try {
                    Thread.sleep(100L);
                    this.aE = 0;
                    this.F();
                }
                catch (Exception exception) {}
                break;
            }
            case 3: {
                this.K += n;
                if (this.K < 4000) break;
                this.O = false;
                this.bc = true;
            }
        }
    }

    private void d(int n, int n2) {
        int n3;
        int n4;
        this.U = com.nokia.mid.appl.disco.b.g(n, this.b(n2, this.bf));
        int n5 = 0;
        while (n5 < this.U) {
            this.aa[n5] = com.nokia.mid.appl.disco.b.g(0, this.U);
            ++n5;
        }
        int n6 = 0;
        while (n6 < this.U) {
            n4 = 0;
            while (n4 < this.U - 1) {
                if (this.aa[n4] >= this.aa[n4 + 1]) {
                    n3 = this.aa[n4];
                    this.aa[n4] = this.aa[n4 + 1];
                    this.aa[n4 + 1] = n3;
                }
                ++n4;
            }
            ++n6;
        }
        n4 = 0;
        while (n4 < this.U - 1) {
            if (this.aa[n4] == this.aa[n4 + 1]) {
                n3 = n4;
                while (n3 < this.U - 1) {
                    this.aa[n3] = this.aa[n3 + 1];
                    ++n3;
                }
                --this.U;
            }
            ++n4;
        }
    }

    private void q() {
        int n = 0;
        while (n < this.U) {
            this.g(this.aa[n]);
            ++n;
        }
        this.U = 0;
    }

    private void h(int n) {
        boolean bl = false;
        int n2 = 100 * this.bs.d() / 150;
        int n3 = 100 * this.bs.b() / 100;
        if (this.p[n] == 0) {
            bl = false;
            n = -1;
        }
        switch (n) {
            case 0: {
                if (n2 <= 80) break;
                this.d(2, 4);
                int n4 = 0;
                while (n4 < this.U) {
                    int n5 = this.aa[n4] * 8;
                    this.u[n5] = 0;
                    this.u[n5 + 1] = 3;
                    this.u[n5 + 2] = 2;
                    ++n4;
                }
                this.bs.f(-com.nokia.mid.appl.disco.b.g(4500, 5500));
                bl = true;
                break;
            }
            case 1: {
                if (n3 >= 50) break;
                this.U = com.nokia.mid.appl.disco.b.g(2, 3);
                if (this.bf + this.U > 10) {
                    this.U = 10 - this.bf;
                }
                int n6 = 0;
                while (n6 < this.U) {
                    this.aa[n6] = this.bf;
                    int n7 = this.bf * 8;
                    this.u[n7] = 1;
                    this.u[n7 + 1] = 1;
                    this.u[n7 + 2] = 6;
                    this.u[n7 + 6] = com.nokia.mid.appl.disco.b.g(70, 120);
                    this.u[n7 + 7] = com.nokia.mid.appl.disco.b.g(70, 120);
                    this.e(this.bf);
                    ++this.bf;
                    ++n6;
                }
                this.G += this.U;
                this.bs.f(com.nokia.mid.appl.disco.b.g(1625, 2275));
                bl = true;
                break;
            }
            case 2: {
                if (n3 <= 80 || this.bs.s() <= 1500) break;
                this.d(3, 4);
                int n8 = 0;
                while (n8 < this.U) {
                    int n9 = this.aa[n8] * 8;
                    this.u[n9] = 0;
                    this.u[n9 + 1] = 2;
                    this.u[n9 + 2] = 7;
                    ++n8;
                }
                this.bs.f(-com.nokia.mid.appl.disco.b.g(4500, 5500));
                bl = true;
                break;
            }
            case 3: {
                if (this.bs.p()) break;
                bl = true;
                break;
            }
            case 4: {
                break;
            }
            case 5: {
                int n10 = this.bs.e(31);
                if (n3 <= 50 || n10 >= 5) break;
                this.bn = n10;
                bl = true;
                break;
            }
            case 6: {
                if (this.bs.u()) break;
                bl = true;
                break;
            }
            case 7: {
                if (n3 <= 80 && (this.bs.i() < 51 || this.bs.i() >= 54)) break;
                bl = true;
                break;
            }
            case 8: {
                if (n3 <= 30 || !this.bs.p()) break;
                bl = true;
                break;
            }
            case 9: {
                if (this.bs.j() < 40) break;
                this.bs.f(-7000);
                bl = true;
                break;
            }
            case 10: {
                if (n2 <= 40 || n3 >= 80) break;
                this.U = 1;
                this.aa[0] = this.bf++;
                ++this.G;
                int n11 = this.aI[2];
                this.bp[n11] = this.aa[0];
                this.U = 1;
                byte by = this.ac[n11];
                int n12 = this.aa[0] * 8;
                this.u[n12] = 0;
                this.u[n12 + 1] = 13;
                this.u[n12 + 2] = 3;
                this.u[n12 + 3] = this.be[by * 2];
                this.u[n12 + 4] = this.be[by * 2 + 1];
                this.bs.f(3250);
                bl = true;
                break;
            }
            case 11: {
                if (this.bs.l() < 20) break;
                this.bs.f(-14000);
                bl = true;
                break;
            }
        }
        if (bl && this.p[n] != 0) {
            int n13 = n;
            this.p[n13] = (byte)(this.p[n13] - 1);
        }
        if (bl) {
            this.aF = n;
            this.as = 0;
        }
        this.aS = 0;
    }

    private void i(int n, int n2) {
        boolean bl = false;
        boolean bl2 = false;
        String string = "";
        this.as += n2;
        int n3 = 100 * this.bs.d() / 150;
        int n4 = 100 * this.bs.b() / 100;
        switch (n) {
            case 0: {
                if (this.as - n2 <= 3000 && this.as > 3000) {
                    string = com.nokia.mid.appl.disco.c.a(102);
                    bl2 = true;
                }
                if (n3 >= 60 && this.as < 30000) break;
                this.q();
                this.bs.f(0);
                bl = true;
                break;
            }
            case 2: {
                if (this.as - n2 <= 3000 && this.as > 3000) {
                    string = com.nokia.mid.appl.disco.c.a(105);
                    bl2 = true;
                }
                if (this.as < 30000) break;
                this.q();
                this.bs.f(0);
                bl = true;
                break;
            }
            case 1: {
                if (this.as - n2 <= 3000 && this.as > 3000) {
                    string = com.nokia.mid.appl.disco.c.a(104);
                    bl2 = true;
                }
                if (this.as < 60000) break;
                this.G -= this.U;
                this.q();
                this.bs.f(0);
                bl = true;
                break;
            }
            case 3: {
                if (this.as - n2 <= 1000 && this.as > 1000) {
                    this.bs.a(58, com.nokia.mid.appl.disco.b.g(2625, 3275));
                    string = com.nokia.mid.appl.disco.c.a(106);
                    bl2 = true;
                }
                if (this.as < 60000) break;
                this.bs.f(0);
                bl = true;
                break;
            }
            case 5: {
                int n5;
                if (this.as - n2 <= 1000 && this.as > 1000) {
                    this.bs.f(-com.nokia.mid.appl.disco.b.g(2625, 3275));
                    string = com.nokia.mid.appl.disco.c.a(107);
                    bl2 = true;
                }
                if (this.bn >= (n5 = this.bs.e(31)) && this.as <= 60000) break;
                this.bs.f(0);
                bl = true;
                break;
            }
            case 6: {
                if (this.as - n2 <= 1000 && this.as > 1000) {
                    this.bs.f(-com.nokia.mid.appl.disco.b.g(1000, 2000));
                    string = com.nokia.mid.appl.disco.c.a(108);
                    bl2 = true;
                }
                if (this.as <= 5000) break;
                this.bs.f(0);
                bl = true;
                break;
            }
            case 7: 
            case 8: {
                int n5;
                if (this.as < 1000) break;
                if (n == 8 && this.bs.p()) {
                    n5 = com.nokia.mid.appl.disco.b.g(0, 4);
                    if (n5 > 0) {
                        if (this.bs.i() >= 51 && this.bs.i() < 53) {
                            this.bs.m();
                        } else {
                            n5 = 0;
                        }
                    }
                    string = com.nokia.mid.appl.disco.c.a(this.ak[n5]);
                    bl2 = true;
                } else if (n == 7 && this.bs.h() > 0) {
                    n5 = this.bs.h();
                    int n6 = com.nokia.mid.appl.disco.b.g(0, n5);
                    int n7 = this.bs.b(n6);
                    if (n7 >= 1 && n7 <= 29) {
                        if (n7 == 2) {
                            int n8 = this.bs.e(n7);
                            if (n8 == -1) {
                                n8 = 0;
                            }
                            this.bs.c(n8);
                        }
                        string = com.nokia.mid.appl.disco.c.a(this.br[n7 - 1]);
                        bl2 = true;
                    } else if (n7 >= 31 && n7 <= 49) {
                        string = com.nokia.mid.appl.disco.c.a(this.D[n7 - 31]);
                        bl2 = true;
                    }
                }
                bl = true;
                break;
            }
            case 9: {
                if (this.as - n2 <= 3000 && this.as > 3000) {
                    string = com.nokia.mid.appl.disco.c.a(110);
                    bl2 = true;
                }
                if (this.bs.j() >= 10 && this.as <= 60000) break;
                this.bs.f(0);
                bl = true;
                break;
            }
            case 10: {
                if (this.as - n2 <= 3000 && this.as > 3000) {
                    string = com.nokia.mid.appl.disco.c.a(103);
                    bl2 = true;
                }
                if (n4 <= 100 && this.as < 60000) break;
                this.G -= this.U;
                this.q();
                this.bs.f(0);
                bl = true;
                break;
            }
            case 11: {
                if (this.as - n2 <= 1000 && this.as > 1000) {
                    string = com.nokia.mid.appl.disco.c.a(109);
                    bl2 = true;
                }
                if (this.bs.l() != 0) break;
                this.bs.f(0);
                bl = true;
                break;
            }
        }
        if (bl) {
            this.aF = -1;
            this.as = 0;
        }
        this.aS = 0;
        if (bl2) {
            while (this.ae.size() > 0) {
                this.ae.delete(0);
            }
            this.ae.setTitle(com.nokia.mid.appl.disco.c.a(25));
            this.ae.append(string);
            this.ae.removeCommand(this.aJ);
            this.ae.addCommand(this.bF);
            this.aO = true;
            this.v.setCurrent((Displayable)this.ae);
            this.bN[this.ax++] = 15;
            this.aU = 2;
        }
    }

    private void j(int n, int n2) {
        int n3;
        this.ar += n;
        if (this.ar > 15000) {
            this.ar = 0;
            n3 = this.B.length / 2 - this.m;
            if (n3 > 4) {
                n3 = 4;
            }
            ++this.a;
            this.a %= n3;
            this.a += this.m;
        }
        n3 = 3 + this.bs.v();
        byte by = this.B[this.a * 2][0];
        switch (by) {
            case 0: {
                byte by2 = this.B[this.a * 2][1];
                byte[] byArray = this.B[this.a * 2 + 1];
                int n4 = n2 / 400 % by2;
                int n5 = 0;
                int n6 = 0;
                int n7 = 0;
                while (n7 < n3) {
                    int n8 = 0;
                    while (n8 < n3) {
                        this.aM[n5 + n8] = byArray[n6 + (n8 + n4) % by2];
                        ++n8;
                    }
                    ++n7;
                    n5 += n3;
                    n6 += by2;
                }
                break;
            }
            case 1: {
                byte by3 = this.B[this.a * 2][1];
                byte by4 = this.B[this.a * 2][2];
                byte[] byArray = this.B[this.a * 2 + 1];
                int n9 = n2 / (by4 * 10) % by3;
                int n10 = 0;
                int n11 = n9 * 6 * 6;
                int n12 = 0;
                while (n12 < n3) {
                    int n13 = 0;
                    while (n13 < n3) {
                        this.aM[n10 + n13] = byArray[n11 + n13];
                        ++n13;
                    }
                    ++n12;
                    n10 += n3;
                    n11 += 6;
                }
                break;
            }
        }
    }

    public void a(Graphics graphics) {
        if (!this.an) {
            return;
        }
        this.an = false;
        int n = (this.getWidth() - 128) / 2;
        int n2 = (this.getHeight() - 128) / 2;
        if (this.aU != 0) {
            if (this.aU == 3) {
                this.b(graphics, n, n2);
                graphics.setFont(this.ab);
                graphics.setColor(0, 0, 0);
                graphics.drawString(com.nokia.mid.appl.disco.c.a(27), 63, 65, 33);
                graphics.setColor(255, 255, 255);
                graphics.drawString(com.nokia.mid.appl.disco.c.a(27), 64, 64, 33);
            } else if (this.bN[this.ax - 1] == 0) {
                this.b(graphics, n, n2);
                if (this.aU == 4) {
                    int n3 = 0;
                    int n4 = this.bs.s() + this.bs.n() * 10 + this.bs.f() * 100;
                    switch (this.I) {
                        case 0: {
                            n3 = 5 * n4 / 24000;
                            break;
                        }
                        case 1: {
                            n3 = 5 * n4 / 24000;
                            break;
                        }
                        case 2: {
                            n3 = 5 * n4 / 24000;
                        }
                    }
                    if (n3 < 1) {
                        n3 = 1;
                    } else if (n3 > 5) {
                        n3 = 5;
                    }
                    int n5 = (this.getWidth() - (n3 * 13 + (n3 - 1) * 6)) / 2 + 6;
                    int n6 = this.getHeight() / 2 - 3 - 7;
                    DirectGraphics directGraphics = DirectUtils.getDirectGraphics((Graphics)graphics);
                    directGraphics.setARGBColor(-1134534560);
                    graphics.setClip(0, 0, this.getWidth(), this.getHeight());
                    graphics.fillRect(0, this.getHeight() / 2 - 15 - 3 - 2, this.getWidth(), 15 + this.ab.getHeight() + 6 + 4);
                    int n7 = 0;
                    while (n7 < n3) {
                        this.a(graphics, n5, n6, 6);
                        n5 += 19;
                        ++n7;
                    }
                    n6 = this.getHeight() / 2 + 3;
                    graphics.setClip(0, 0, this.getWidth(), this.getHeight());
                    graphics.setFont(this.ab);
                    graphics.setColor(0, 0, 0);
                    graphics.drawString("" + n4, this.getWidth() / 2, n6, 17);
                    graphics.setColor(255, 255, 255);
                    graphics.drawString("" + n4, this.getWidth() / 2 - 1, n6 - 1, 17);
                }
            }
        }
    }

    private void b(Graphics graphics, int n, int n2) {
        Graphics graphics2;
        int n3;
        int n4;
        int n5;
        int n6;
        int n7;
        int n8;
        int n9;
        int n10;
        int n11;
        int n12;
        int n13;
        graphics.translate(n, n2);
        graphics.setClip(0, 0, 128, 128);
        this.g(graphics);
        int n14 = 15;
        int n15 = 15;
        int n16 = 51;
        int n17 = 63;
        int n18 = n14 / 2;
        int n19 = n15 / 2;
        int n20 = 0;
        while (n20 < 2) {
            graphics.setClip(n16, n17, n14, n15);
            graphics.drawImage(this.c, n16 - n14, n17, 20);
            n16 += n14 - 1;
            n17 -= n19;
            ++n20;
        }
        n16 = 51 - n14;
        n17 = 63;
        int n21 = 0;
        while (n21 < 2) {
            graphics.setClip(n16, n17, n14, n15);
            graphics.drawImage(this.c, n16, n17, 20);
            n16 -= n14 - 1;
            n17 -= n19;
            ++n21;
        }
        if (this.bs.p()) {
            n13 = this.bs.i() - 50 - 1;
            this.ag = true;
            this.k = 2;
            this.bD = 3;
            this.L = 0;
            this.aX = 256 + (n13 + 1) * 64;
            this.m = 4;
            if (this.bs.g()) {
                switch (this.bs.a()) {
                    case 0: {
                        this.ap = true;
                        break;
                    }
                }
            }
            n12 = this.P[n13 * 2];
            n11 = this.P[n13 * 2 + 1];
            n10 = 0;
            if (n11 == 3) {
                n10 = 2;
            } else if (n11 == 2) {
                n10 = 7;
            }
            n9 = this.Z / (this.L + 200) % 2;
            n8 = this.Z / (this.L + 200) % 2;
            this.a(graphics, 34, 61, n11, n9, n10, n8);
        } else {
            this.ag = false;
            this.ap = false;
            this.k = 4;
            this.bD = 1;
            this.L = 200;
            this.aX = 256;
            this.m = 0;
        }
        n16 = 51;
        n17 = 53;
        n14 = 13;
        n15 = 18;
        n18 = n14 / 2;
        n19 = n15 / 2;
        n13 = (this.R - 1) / 2 * 60;
        n12 = 0;
        while (n12 < 3) {
            graphics.setClip(n16, n17, n14, n15);
            graphics.drawImage(this.aH, n16 - n14 - n13, n17, 20);
            n16 += 9;
            n17 -= 5;
            ++n12;
        }
        n16 = 38;
        n17 = 53;
        n11 = 0;
        while (n11 < 3) {
            graphics.setClip(n16, n17, n14, n15);
            graphics.drawImage(this.aH, n16 - n13, n17, 20);
            n16 -= 9;
            n17 -= 5;
            ++n11;
        }
        this.e(graphics);
        this.a(graphics, this.aM);
        this.f(graphics);
        this.c(graphics);
        this.d(graphics);
        if (this.bs.e(4) == 1) {
            this.a(graphics, 100, 11, this.X / this.k % 3 == 0);
        }
        n10 = 0;
        while (n10 < this.ac.length) {
            if (this.bp[n10] != -1) {
                n9 = this.bp[n10] * 8;
                n8 = this.Z / (this.u[n9 + 6] + this.L) % 2;
                n7 = this.Z / (this.u[n9 + 7] + this.L) % 2;
                this.a(graphics, this.u[n9 + 3], this.u[n9 + 4], this.u[n9 + 1], n8, this.u[n9 + 2], n7);
            }
            ++n10;
        }
        n9 = this.bs.e(3);
        if (n9 == 1 || n9 == 2) {
            n8 = this.Z / (this.L + 150) % 3;
            n7 = this.Z / (this.L + 200) % 2;
            this.a(graphics, -2, 125, n8, n7);
        }
        if (n9 == 2) {
            n8 = this.Z / (this.L + 190) % 3;
            n7 = this.Z / (this.L + 250) % 2;
            this.a(graphics, 102, 125, n8, n7);
        }
        switch (this.aF) {
            case 0: {
                if (this.as < 10000) {
                    n8 = 1 + (10000 - this.as) / 1000;
                    n7 = 0;
                    while (n7 < this.U && n8 > 0) {
                        n6 = this.aa[n7] * 8;
                        n5 = this.u[n6 + 3];
                        n4 = this.u[n6 + 4];
                        n3 = n4 - 11;
                        this.a(graphics, n5, 11, 25, n3, n8);
                        ++n7;
                    }
                }
                if (this.X / 1 % 3 <= 0) break;
                n8 = 1;
                n8 = 1 + this.bf * this.as / 1000 / 10;
                if (n8 > 10) {
                    n8 = 10;
                }
                this.a(graphics, n8, 0);
                break;
            }
            case 6: 
            case 9: {
                if (this.X / 1 % 3 <= 0) break;
                n8 = 1;
                n8 = 1 + this.bf * this.as / 1000 / 10;
                if (n8 > 10) {
                    n8 = 10;
                }
                this.a(graphics, n8, 0);
                break;
            }
            case 10: {
                if (this.as < 40000) {
                    n8 = 1 + (40000 - this.as) / 1000;
                    if (n8 > 3) {
                        n8 = 3;
                    }
                    n7 = 0;
                    while (n7 < this.U && n8 > 0) {
                        n6 = this.aa[n7] * 8;
                        n5 = this.u[n6 + 3];
                        n4 = this.u[n6 + 4] - 19 - 26;
                        this.a(graphics, n5, n4, 25, 45, n8);
                        ++n7;
                    }
                }
                if (this.X / 1 % 3 <= 0) break;
                n8 = 1;
                n8 = 1 + this.bf * this.as / 1000 / 10;
                if (n8 > 4) {
                    n8 = 4;
                }
                this.a(graphics, n8, 7);
                break;
            }
            case 1: {
                if (this.X / 1 % 3 <= 0) break;
                n8 = 1;
                n8 = 1 + this.bf * this.as / 1000 / 10;
                if (n8 > 4) {
                    n8 = 4;
                }
                this.a(graphics, n8, 7);
                break;
            }
            case 3: {
                this.a(graphics, 0, 11, 128, 117, 10);
                if (this.X / 1 % 3 <= 0) break;
                n8 = 1;
                n8 = 1 + this.bf * this.as / 1000 / 10;
                if (n8 > 4) {
                    n8 = 4;
                }
                this.a(graphics, n8, 7);
                break;
            }
            case 11: {
                if (this.X / 1 % 3 <= 0) break;
                n8 = 1;
                n8 = 1 + this.bf * this.as / 1000 / 10;
                if (n8 > 10) {
                    n8 = 10;
                }
                this.a(graphics, n8, 0);
                break;
            }
        }
        this.b(graphics);
        if (this.bs.g()) {
            switch (this.bs.a()) {
                case 1: 
                case 2: {
                    this.a(graphics, 0, 11, 128, 117, 15);
                    break;
                }
            }
        }
        n8 = this.C[0].getWidth();
        n7 = this.C[0].getHeight();
        graphics.setClip(0, 0, 128, 128);
        n6 = 11;
        graphics.setColor(255, 255, 255);
        graphics.fillRect(0, 0, 128, n6);
        graphics.setColor(142, 142, 142);
        graphics.fillRect(0, n6, 128, 1);
        graphics.setColor(142, 142, 142);
        graphics.fillRect(4, 0, 124, 1);
        graphics.setColor(218, 218, 218);
        graphics.fillRect(4, 1, 124, 1);
        graphics.setColor(218, 218, 218);
        graphics.fillRect(4, 10, 124, 2);
        graphics.setClip(0, 0, 4, 14);
        graphics.drawImage(this.Y, -this.Y.getWidth() + 4, 0, 20);
        n5 = 1;
        n4 = 1;
        if (!this.bs.o() || this.X % 2 == 0) {
            graphics.setClip(n4, n5, 11, 14);
            graphics.drawImage(this.Y, n4 -= 13, n5, 20);
        }
        if (!this.bs.t() || this.X % 2 == 0) {
            n5 = 1;
            n4 = 117 - n8 * 3;
            graphics.setClip(n4, n5, 10, 10);
            graphics.drawImage(this.Y, n4 -= 24, n5, 20);
        }
        n5 = 1;
        n4 = (121 - n8 * 5 - 2) / 2 - 1;
        graphics.setClip(n4, n5, 7, 12);
        graphics.drawImage(this.Y, n4 -= 34, n5, 20);
        graphics.setClip(0, 0, 128, 128);
        if (this.aU == 1 || this.I != 2 && this.aU == 4 || this.I == 2 && this.aU == 4 && this.X % 2 == 0) {
            n4 = 13;
            n5 = 2;
            n3 = this.bs.b();
            if (n3 < 0) {
                n3 = 0;
            }
            this.a(graphics, n4, n5, this.C, n8, 3, n3);
        }
        if (this.aU == 1 || this.I != 1 && this.aU == 4 || this.I == 1 && this.aU == 4 && this.X % 2 == 0) {
            n4 = 127 - n8 * 3;
            n5 = 2;
            n3 = 100 * this.bs.d() / 150;
            if (n3 < 0) {
                n3 = 0;
            } else if (n3 > 100) {
                n3 = 100;
            }
            this.a(graphics, n4, n5, this.C, n8, 3, n3);
        }
        if (this.aU == 1 || this.I != 0 && this.aU == 4 || this.I == 0 && this.aU == 4 && this.X % 2 == 0) {
            n4 = (121 - n8 * 6 - 2) / 2 + 7 + 1;
            n5 = 2;
            n3 = this.bs.s();
            if (n3 < 0) {
                n3 = 0;
            }
            this.a(graphics, n4, n5, this.C, n8, 6, n3);
        }
        graphics.setClip(0, 0, 128, 128);
        n3 = this.bs.k() / 30 + 1;
        if (n3 != this.l) {
            String string;
            if (this.N == null) {
                string = com.nokia.mid.appl.disco.c.a(24, new String[]{"00"});
                int n22 = this.aW.stringWidth(string) + 2;
                int n23 = this.aW.getHeight() + 2;
                this.N = Image.createImage((int)n22, (int)n23);
            }
            string = com.nokia.mid.appl.disco.c.a(24, new String[]{"" + n3});
            this.l = n3;
            graphics2 = this.N.getGraphics();
            graphics2.setFont(this.aW);
            graphics2.setColor(128, 128, 128);
            graphics2.fillRect(0, 0, this.N.getWidth(), this.N.getHeight());
            graphics2.setColor(255, 255, 255);
            graphics2.fillRect(1, 1, this.N.getWidth() - 1, this.N.getHeight() - 1);
            graphics2.setColor(0, 0, 0);
            graphics2.drawString(string, 2, 2, 20);
            this.Q = this.aW.stringWidth(string) + 2;
        }
        graphics.drawImage(this.N, this.getWidth() - this.Q, this.getHeight() - 1, 36);
        if (this.bs.e()) {
            graphics.setClip(0, 0, 128, 128);
            int n24 = this.aW.stringWidth(this.af);
            graphics2 = DirectUtils.getDirectGraphics((Graphics)graphics);
            graphics2.setARGBColor(-1134534560);
            graphics.fillRect(0, 64 - this.aW.getHeight() - 2, 128, this.aW.getHeight() + 4);
            if (this.X / 1 % 3 > 0) {
                graphics.setColor(255, 255, 255);
                graphics.setFont(this.aW);
                graphics.drawString(this.af, 64, 64, 33);
            }
        }
        graphics.translate(-n, -n2);
    }

    private void a(Graphics graphics, int n, int n2) {
        int n3 = this.ac.length - 1;
        while (n3 >= 0 && n > 0) {
            if (this.bp[n3] != -1) {
                int n4 = this.bp[n3] * 8;
                int n5 = 9;
                int n6 = 11;
                if (n2 != 0) {
                    n5 = 10;
                    n6 = 10;
                }
                int n7 = this.u[n4 + 3] + (22 - n5) / 2;
                int n8 = this.u[n4 + 4] - 19 - 26 - n6 / 2;
                this.a(graphics, n7, n8, n2);
                --n;
            }
            --n3;
        }
    }

    private void b(Graphics graphics, int n, int n2, int n3) {
        int n4 = (this.R - 1) / 2 * 60;
        graphics.setClip(n, n2 -= 17, 17, 17);
        graphics.drawImage(this.aH, n - 26 - n4, n2, 20);
        switch (n3) {
            case 0: {
                graphics.setClip(n, n2 -= 5, 17, 5);
                graphics.drawImage(this.aH, n - 26 - 17 - n4, n2, 20);
                break;
            }
            case 1: {
                graphics.setClip(n, n2 -= 17, 17, 17);
                graphics.drawImage(this.aH, n - 26 - 17 - n4, n2, 20);
                break;
            }
            case 2: {
                graphics.setClip(n, n2 -= 12, 17, 12);
                graphics.drawImage(this.aH, n - 26 - 17 - n4, n2 - 5, 20);
                graphics.setClip(n, n2 -= 17, 17, 17);
                graphics.drawImage(this.aH, n - 26 - 17 - n4, n2, 20);
            }
        }
    }

    private void f(Graphics graphics) {
        int n = this.bs.e(31);
        int n2 = -1;
        int n3 = -1;
        int n4 = -1;
        int n5 = -1;
        switch (n) {
            default: {
                n2 = 0;
                n5 = 0;
                break;
            }
            case 1: {
                n2 = 1;
                n5 = 1;
                break;
            }
            case 2: {
                n2 = 1;
                n3 = 0;
                n4 = 0;
                n5 = 1;
                break;
            }
            case 3: {
                n2 = 1;
                n3 = 1;
                n4 = 1;
                n5 = 1;
                break;
            }
            case 4: {
                n2 = 2;
                n3 = 1;
                n4 = 1;
                n5 = 2;
                break;
            }
            case 5: {
                n2 = 2;
                n3 = 2;
                n4 = 2;
                n5 = 2;
            }
        }
        if (n2 >= 0) {
            this.b(graphics, this.bo[0], this.bo[1], n2);
        }
        if (n5 >= 0) {
            this.b(graphics, this.bo[6], this.bo[7], n5);
        }
        if (n3 >= 0) {
            this.b(graphics, this.bo[2], this.bo[3], n3);
        }
        if (n4 >= 0) {
            this.b(graphics, this.bo[4], this.bo[5], n4);
        }
    }

    private void a(Graphics graphics, int n, int n2, int n3) {
        int n4 = 0;
        int n5 = 0;
        int n6 = n;
        int n7 = n2;
        int n8 = 0;
        int n9 = 0;
        switch (n3) {
            case 0: {
                n4 = 41;
                n8 = 9;
                n9 = 11;
                break;
            }
            case 1: {
                n4 = 50;
                n8 = 8;
                n9 = 7;
                break;
            }
            case 2: {
                n4 = 58;
                n8 = 4;
                n9 = 7;
                break;
            }
            case 3: {
                n4 = 62;
                n8 = 7;
                n9 = 7;
                break;
            }
            case 4: {
                n4 = 69;
                n5 = 3;
                n8 = 5;
                n9 = 5;
                n6 -= 2;
                n7 -= 2;
                break;
            }
            case 5: {
                n4 = 74;
                n5 = 0;
                n8 = 9;
                n9 = 11;
                n6 -= 4;
                n7 -= 5;
                break;
            }
            case 6: {
                n4 = 0;
                n5 = 0;
                n8 = 13;
                n9 = 15;
                n6 -= 6;
                n7 -= 7;
                break;
            }
            case 7: {
                n4 = 24;
                n5 = 0;
                n8 = 10;
                n9 = 10;
                n6 -= 5;
                n7 -= 5;
            }
        }
        graphics.setClip(n6, n7, n8, n9);
        graphics.drawImage(this.Y, n6 - n4, n7 - n5, 20);
    }

    private void a(Graphics graphics, int n, int n2, boolean bl) {
        int n3 = n;
        int n4 = n2;
        graphics.setClip(n3, n4, 23, 28);
        graphics.drawImage(this.bm, n3 += 0, n4, 20);
        if (bl) {
            n3 = n + -4;
            n4 = n2 + 24;
            graphics.setClip(n3, n4, 27, 14);
            graphics.drawImage(this.bm, n3 -= 23, n4, 20);
        }
    }

    private void a(Graphics graphics, int n, int n2, int n3, int n4) {
        int n5 = n;
        int n6 = n2 - 19;
        graphics.setClip(n5, n6, 28, 19);
        graphics.drawImage(this.c, n5 -= 30, n6, 20);
        this.a(graphics, n + 4, n2 - 12, 10, n3, 4, n4);
        n5 = n + 2;
        n6 = n2 - 28 - 19;
        graphics.setClip(n5, n6, 24, 28);
        graphics.drawImage(this.c, n5 -= 85, n6, 20);
        n5 = n + 2;
        n6 = n2 - 56 - 19;
        graphics.setClip(n5, n6, 24, 28);
        graphics.drawImage(this.c, n5 -= 58, n6, 20);
    }

    private void e(Graphics graphics) {
        int n = this.bs.e(32);
        int n2 = 31;
        int n3 = 45;
        int n4 = 0;
        while (n4 < n && n4 < 2) {
            graphics.setClip(n2, n3, 16, 8);
            graphics.drawImage(this.aZ, n2 - 19, n3, 20);
            n2 -= 10;
            n3 -= 4;
            ++n4;
        }
        if (n < 0) {
            n = 1;
        }
        n2 = 41;
        n3 = 46;
        n2 += 10 * (n - 1);
        n3 -= 5 * (n - 1);
        int n5 = 0;
        while (n5 < n) {
            graphics.setClip(n2, n3, 18, 12);
            graphics.drawImage(this.aZ, n2 - 0, n3, 20);
            n2 -= 10;
            n3 += 5;
            ++n5;
        }
    }

    private void c(Graphics graphics) {
        int n;
        int n2;
        int n3 = this.bs.e(1);
        int n4 = 0;
        while (n4 < n3 * 2) {
            n2 = this.ad[n4 * 2];
            n = this.ad[n4 * 2 + 1];
            graphics.setClip(n2, n, 20, 12);
            graphics.drawImage(this.bm, n2 -= 50, n, 20);
            ++n4;
        }
        n2 = this.X;
        if (n2 % 2 == 0) {
            n2 = n2 / 2 * this.bD;
            n = 0;
            while (n < this.bD) {
                int n5 = this.F[(n + n2) % this.F.length];
                if (n5 + 1 <= n3 * 2) {
                    int n6 = this.ad[n5 * 2];
                    int n7 = this.ad[n5 * 2 + 1];
                    graphics.setClip(++n6, n7 -= 8, 17, 19);
                    graphics.drawImage(this.bm, n6 -= 70, n7, 20);
                }
                ++n;
            }
        }
    }

    private void a(Graphics graphics, int n, int n2, Image[] imageArray, int n3, int n4, int n5) {
        n += (n4 - 1) * n3;
        int n6 = 0;
        while (n6 < n4) {
            int n7 = n5 % 10;
            if (n7 == 0 && n6 != 0 && (n5 /= 10) == 0) {
                n7 = 10;
            }
            graphics.drawImage(imageArray[n7], n, n2, 20);
            n -= n3;
            ++n6;
        }
    }

    private void a(Graphics graphics, int n, int n2, int n3, int n4, int n5, int n6) {
        n2 -= 19;
        int n7 = n5 * 2 * 22 + n6 * 22;
        int n8 = n3 * 2 * 25 + n4 * 25;
        if (n3 > 10) {
            n8 += 25;
        }
        DirectGraphics directGraphics = DirectUtils.getDirectGraphics((Graphics)graphics);
        boolean bl = false;
        if (n > 64) {
            bl = true;
            n7 = this.r.getWidth() - n7 - 22;
            n8 = this.bB.getWidth() - n8 - 25;
        }
        graphics.setClip(n, n2, 22, 19);
        if (n3 == 3) {
            if (bl) {
                directGraphics.drawImage(this.r, n - n7, n2 - 7, 20, 8192);
            } else {
                graphics.drawImage(this.r, n - n7, n2 - 7, 20);
            }
        } else if (n3 == 2) {
            if (bl) {
                directGraphics.drawImage(this.r, n - n7, n2 - 7, 20, 8192);
            } else {
                graphics.drawImage(this.r, n - n7, n2 - 7, 20);
            }
        } else if (bl) {
            directGraphics.drawImage(this.r, n - n7, n2, 20, 8192);
        } else {
            graphics.drawImage(this.r, n - n7, n2, 20);
        }
        n -= 3;
        n2 -= 26;
        switch (n3) {
            case 11: {
                n = bl ? (n += 3) : (n += 0);
                ++n2;
                break;
            }
            case 12: {
                n = bl ? (n += 0) : (n += 2);
                n2 += 4;
                break;
            }
            case 0: 
            case 4: 
            case 6: {
                n = bl ? (n += 3) : (n += 0);
                n2 += 2;
                break;
            }
            case 5: {
                n = bl ? (n += 3) : (n += 0);
                n2 += 0;
                break;
            }
            case 2: 
            case 3: {
                n = bl ? (n += 2) : ++n;
                n2 += 0;
                break;
            }
            case 13: {
                n = bl ? (n += 0) : (n += 2);
                n2 += 4;
                break;
            }
            case 8: {
                n = bl ? (n += 4) : --n;
                n2 += 3;
                break;
            }
            case 9: {
                n = bl ? (n += 4) : (n += 0);
                n2 += 6;
                break;
            }
            case 10: {
                n = bl ? (n += 3) : (n += 0);
                n2 += 3;
                break;
            }
            case 1: {
                n = bl ? ++n : (n += 2);
                n2 += 5;
                break;
            }
            case 7: {
                n = bl ? (n += 2) : (n += 0);
                n2 += 0;
            }
        }
        graphics.setClip(n, n2, 25, 26);
        if (bl) {
            directGraphics.drawImage(this.bB, n - n8, n2, 20, 8192);
        } else {
            graphics.drawImage(this.bB, n - n8, n2, 20);
        }
    }

    private void a(Graphics graphics, byte[] byArray) {
        int n = 4;
        int n2 = 41 - (n + 1 - 6) * 22;
        int n3 = 39 + (n + 1 - 2) * 12 - 6;
        int n4 = 22;
        int n5 = 12;
        int n6 = 11;
        int n7 = 6;
        int n8 = 3 + this.bs.v();
        if (n8 == 3) {
            n3 += 12;
        } else if (n8 == 4) {
            n3 += 12;
        }
        int n9 = 0;
        int n10 = 0;
        while (n10 < n8) {
            int n11 = n2;
            int n12 = n3;
            int n13 = 0;
            while (n13 < n8) {
                graphics.setClip(n11, n12, n4, n5);
                graphics.drawImage(this.ba, n11 - n4 * (byArray[n9] + 7 - 2), n12, 20);
                n11 += n6 + 1;
                n12 += n7;
                ++n13;
                ++n9;
            }
            n2 -= n6 + 1;
            n3 += n7;
            ++n10;
        }
    }

    private void m() {
        int n;
        if ((n = this.bf++) < this.u.length / 8) {
            this.g(n);
            this.e(n);
        }
    }

    private void f(int n) {
        int n2 = 0;
        while (n2 < this.bp.length) {
            if (this.bp[n2] == n) {
                this.bp[n2] = -1;
                break;
            }
            ++n2;
        }
    }

    private void e(int n) {
        this.f(n);
        int n2 = n;
        n *= 8;
        int n3 = 0;
        switch (this.bs.v()) {
            default: {
                n3 = 5;
                break;
            }
            case 1: {
                n3 = 7;
                break;
            }
            case 2: {
                n3 = 9;
                break;
            }
            case 3: {
                n3 = 11;
            }
        }
        int n4 = 0;
        int n5 = 0;
        n3 = 11;
        while (n5 < n3 && this.bp[this.aI[n4]] != -1) {
            ++n4;
            n4 %= n3;
            ++n5;
        }
        int n6 = this.aI[n4];
        this.bp[n6] = n2;
        n4 = this.ac[n6];
        this.u[n + 3] = this.be[n4 * 2];
        this.u[n + 4] = this.be[n4 * 2 + 1];
    }

    private void g(int n) {
        int n2 = n * 8;
        this.u[n2] = com.nokia.mid.appl.disco.b.g(0, 2);
        this.u[n2 + 1] = com.nokia.mid.appl.disco.b.g(0, 3);
        if (this.u[n2] == 0) {
            switch (this.u[n2 + 1]) {
                case 0: {
                    this.u[n2 + 1] = 11;
                    break;
                }
                case 1: {
                    this.u[n2 + 1] = 12;
                    break;
                }
                case 2: {
                    this.u[n2 + 1] = 0;
                }
            }
        } else {
            switch (this.u[n2 + 1]) {
                case 0: 
                case 1: {
                    this.u[n2 + 1] = 8;
                    break;
                }
                case 2: {
                    this.u[n2 + 1] = 9;
                }
            }
        }
        switch (this.u[n2 + 1]) {
            case 8: {
                this.u[n2 + 2] = 5;
                break;
            }
            case 9: {
                this.u[n2 + 2] = 4;
                break;
            }
            case 10: {
                this.u[n2 + 2] = 4;
                break;
            }
            case 1: {
                this.u[n2 + 2] = 6;
                break;
            }
            case 7: {
                this.u[n2 + 2] = 4;
                break;
            }
            case 3: {
                this.u[n2 + 2] = 2;
                break;
            }
            case 13: {
                this.u[n2 + 2] = 3;
                break;
            }
            default: {
                this.u[n2 + 2] = com.nokia.mid.appl.disco.b.g(0, 2);
            }
        }
        this.u[n2 + 5] = com.nokia.mid.appl.disco.b.g(0, 2);
        this.u[n2 + 6] = com.nokia.mid.appl.disco.b.g(100, 200);
        this.u[n2 + 7] = com.nokia.mid.appl.disco.b.g(100, 200);
    }

    private void A() {
        int n = 10;
        int n2 = 80;
        int n3 = 0;
        while (n3 < 2) {
            int n4 = this.al + n3;
            this.g(n4 %= this.u.length / 8);
            ++n3;
        }
        this.al += 2;
    }

    private void h(int n, int n2) {
        int n3;
        this.az = 0;
        this.bf = 0;
        int n4 = 10;
        int n5 = 91;
        int n6 = 0;
        while (n6 < 10) {
            n3 = n6 * 8;
            this.g(n6);
            ++n6;
        }
        n3 = 0;
        while (n3 < this.bp.length) {
            this.bp[n3] = -1;
            ++n3;
        }
        this.H();
        this.t();
        this.l = -1;
        this.bs.g(n);
        this.aF = -1;
        this.as = 0;
        this.aS = 0;
        this.G = 0;
        this.ax = 0;
        this.bN[this.ax++] = 0;
        this.m = 0;
        this.a = 0;
        this.bD = 1;
        this.k = 4;
        this.bc = false;
        this.O = true;
        this.an = true;
        this.Z = 0;
        this.bA = 0;
        this.d = 0;
        this.bd = false;
        this.aL = false;
        this.aU = 0;
        this.bt = 0;
        this.e = n2;
        this.au = n;
        this.aE = 0;
        if (this.av) {
            this.I();
            this.av = false;
        }
    }

    private void i() {
        try {
            this.bm = Image.createImage((String)"/light.png");
            this.ba = Image.createImage((String)"/floor.png");
            this.c = Image.createImage((String)"/stage.png");
            this.bB = Image.createImage((String)"/body.png");
            this.r = Image.createImage((String)"/legs.png");
            this.Y = Image.createImage((String)"/symbols.png");
            this.aZ = Image.createImage((String)"/player.png");
            this.aH = Image.createImage((String)"/table.png");
            this.R = 1;
            this.C = this.d();
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private void t() {
        if (this.bH == null) {
            this.bH = new int[60];
        }
        int n = 10;
        int n2 = 0;
        while (n2 < this.bH.length) {
            this.bH[n2 + 1] = n2 < 4 ? com.nokia.mid.appl.disco.b.g(0, 42) << 4 : this.bH[n2 % 4 + 1] + n2 / 4 * 128 / 3;
            this.bH[n2 + 3] = com.nokia.mid.appl.disco.b.g(80, 120);
            this.bH[n2 + 2] = 0;
            this.bH[n2 + 4] = n2 % 4;
            n2 += 5;
        }
    }

    private void a(int n) {
        int n2 = this.bs.e(31);
        int n3 = 0;
        while (n3 < this.bH.length) {
            if (this.bH[n3 + 4] < 2) {
                int n4 = n3;
                this.bH[n4] = this.bH[n4] + n * this.bH[n3 + 3] / 1000 / 2;
            } else {
                int n5 = n3;
                this.bH[n5] = this.bH[n5] - n * this.bH[n3 + 3] / 1000 / 2;
            }
            int n6 = n3 + 1;
            this.bH[n6] = this.bH[n6] - n * this.bH[n3 + 3] / 1000;
            if (this.bH[n3 + 1] >> 4 < 7) {
                this.bH[n3 + 3] = this.aX * com.nokia.mid.appl.disco.b.g(80, 120) >> 8;
                this.bH[n3] = this.bo[this.bH[n3 + 4] * 2] + 6 << 4;
                this.bH[n3 + 1] = this.bo[this.bH[n3 + 4] * 2 + 1] - 7 << 4;
                int n7 = this.bH[n3 + 4];
                this.bH[n3 + 2] = this.ag && (n7 == 0 || n7 == 3 || n2 >= 3) ? com.nokia.mid.appl.disco.b.g(1, 3) : 0;
            }
            n3 += 5;
        }
    }

    private void d(Graphics graphics) {
        if (this.bH != null) {
            int n = 0;
            while (n < this.bH.length) {
                if (this.bH[n + 2] >= 1) {
                    int n2 = this.bH[n] >> 4;
                    int n3 = this.bH[n + 1] >> 4;
                    this.a(graphics, n2, n3, this.bH[n + 2]);
                }
                n += 5;
            }
        }
    }

    private void H() {
        if (this.aB == null) {
            this.aB = new int[60];
        }
        int n = 10;
        int n2 = 0;
        while (n2 < this.aB.length) {
            this.aB[n2] = n << 4;
            this.aB[n2 + 1] = com.nokia.mid.appl.disco.b.g(0, 128) << 4;
            this.aB[n2 + 3] = com.nokia.mid.appl.disco.b.g(112, 134);
            this.aB[n2 + 2] = 0;
            n += 7 + com.nokia.mid.appl.disco.b.g(-5, 5);
            n2 += 4;
        }
    }

    private void c(int n) {
        int n2 = 0;
        while (n2 < this.aB.length) {
            int n3 = n2 + 1;
            this.aB[n3] = this.aB[n3] + n * this.aB[n2 + 3] / 1000;
            if (this.aB[n2 + 2] > 0) {
                int n4 = n2 + 2;
                this.aB[n4] = this.aB[n4] + 1;
                if (this.aB[n2 + 2] < 10) {
                    int n5 = n2 + 3;
                    this.aB[n5] = this.aB[n5] - 5;
                } else if (this.aB[n2 + 2] < 20) {
                    int n6 = n2 + 3;
                    this.aB[n6] = this.aB[n6] + 5;
                } else {
                    this.aB[n2 + 2] = 1;
                }
            }
            if (this.aB[n2 + 1] >> 4 > 128) {
                this.aB[n2 + 1] = -7;
                this.aB[n2 + 3] = com.nokia.mid.appl.disco.b.g(112, 134);
                this.aB[n2 + 2] = this.ap ? 1 : 0;
            }
            n2 += 4;
        }
    }

    private void b(Graphics graphics) {
        if (this.aB != null) {
            int n = 0;
            while (n < this.aB.length) {
                if (this.aB[n + 2] >= 1) {
                    int n2 = this.aB[n] >> 4;
                    int n3 = this.aB[n + 1] >> 4;
                    this.a(graphics, n2, n3, 3);
                }
                n += 4;
            }
        }
    }

    private int b(int n, int n2) {
        if (n < n2) {
            return n;
        }
        return n2;
    }

    static int g(int n, int n2) {
        int n3 = aC.nextInt();
        if (n3 < 0) {
            n3 = -n3;
        }
        n3 = n2 <= n ? 0 : (n3 %= n2 - n);
        return n + n3;
    }

    public Image[] a(Image image, int n, int n2, int n3, int n4) {
        Image[] imageArray = new Image[n2];
        int n5 = 0;
        while (n5 < n2) {
            imageArray[n5] = Image.createImage((int)n3, (int)n4);
            int n6 = n % image.getWidth();
            int n7 = n / image.getWidth() * n4;
            imageArray[n5].getGraphics().drawImage(image, n6, n7, 20);
            ++n5;
            n -= n3;
        }
        return imageArray;
    }

    public Image[] d() throws Exception {
        Image image = Image.createImage((String)"/numbers.png");
        return this.a(image, 0, 11, 5, image.getHeight());
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void C() {
        var1_1 = null;
        try {
            var1_1 = new DataInputStream(this.getClass().getResourceAsStream("/data.bin"));
            var2_2 = var1_1.readByte();
            this.B = new byte[var2_2 * 2][];
            var3_4 = 0;
            if (true) ** GOTO lbl36
        }
        catch (Exception var2_3) {
            var2_3.printStackTrace();
            return;
        }
        do {
            this.B[var3_4 * 2] = new byte[3];
            var4_5 = 0;
            while (var4_5 < this.B[var3_4 * 2].length) {
                this.B[var3_4 * 2][var4_5] = var1_1.readByte();
                ++var4_5;
            }
            var5_6 = var1_1.readShort();
            this.B[var3_4 * 2 + 1] = new byte[var5_6];
            var6_7 = this.B[var3_4 * 2 + 1];
            var7_9 = 0;
            while (var5_6 > 0) {
                var8_10 = var1_1.readInt();
                var9_11 = 0;
                while (var9_11 < 32 && var5_6 > 0) {
                    var6_7[var7_9] = (byte)(2 + (var8_10 >> var9_11 & 1));
                    ++var9_11;
                    --var5_6;
                    ++var7_9;
                }
            }
            ++var3_4;
lbl36:
            // 2 sources

        } while (var3_4 < var2_2);
        var4_5 = var1_1.readByte();
        this.T = new int[var4_5];
        this.y = new byte[var4_5 * 2];
        this.a((DataInputStream)var1_1, this.T, this.y);
        var4_5 = var1_1.readByte();
        this.bv = new int[var4_5];
        this.aj = new byte[var4_5 * 2];
        this.a((DataInputStream)var1_1, this.bv, this.aj);
        var4_5 = var1_1.readByte();
        this.aw = new int[var4_5];
        this.bG = new byte[var4_5 * 2];
        this.a((DataInputStream)var1_1, this.aw, this.bG);
        var4_5 = var1_1.readByte();
        this.aT = new int[var4_5];
        this.by = new byte[var4_5 * 2];
        this.a((DataInputStream)var1_1, this.aT, this.by);
        var5_6 = var1_1.readByte();
        this.P = new byte[var5_6];
        var6_8 = 0;
        while (var6_8 < this.P.length) {
            this.P[var6_8] = var1_1.readByte();
            ++var6_8;
        }
        var4_5 = var1_1.readByte();
        this.ad = new int[var4_5];
        var7_9 = 0;
        while (var7_9 < var4_5) {
            var8_10 = var7_9 / 2 % 2;
            if (var7_9 < 18 && var8_10 == 0) {
                this.ad[var7_9] = -5 + var1_1.readByte() * 14;
                this.ad[var7_9 + 1] = 11 + var1_1.readByte() * 12;
            } else {
                this.ad[var7_9] = 53 + var1_1.readByte() * 14;
                this.ad[var7_9 + 1] = 11 + var1_1.readByte() * 12;
            }
            var7_9 += 2;
        }
        var8_10 = var1_1.readByte();
        this.bp = new int[var8_10 / 2];
        var9_11 = 0;
        while (var9_11 < this.bp.length) {
            this.bp[var9_11] = -1;
            ++var9_11;
        }
        var10_12 = new byte[var8_10];
        this.aI = new int[var8_10 / 2];
        this.ac = new byte[var8_10 / 2];
        this.be = new byte[var8_10];
        var11_13 = 0;
        while (var11_13 < this.be.length) {
            this.be[var11_13] = var1_1.readByte();
            var10_12[var11_13] = this.be[var11_13];
            ++var11_13;
        }
        var12_14 = 0;
        while (var12_14 < this.ac.length) {
            this.ac[var12_14] = (byte)var12_14;
            ++var12_14;
        }
        var13_15 = 0;
        while (var13_15 < this.ac.length) {
            var14_16 = var13_15 + 1;
            while (var14_16 < this.ac.length) {
                if (var10_12[var14_16 * 2 + 1] < var10_12[var13_15 * 2 + 1]) {
                    var15_17 = var10_12[var14_16 * 2];
                    var10_12[var14_16 * 2] = var10_12[var13_15 * 2];
                    var10_12[var13_15 * 2] = var15_17;
                    var15_17 = var10_12[var14_16 * 2 + 1];
                    var10_12[var14_16 * 2 + 1] = var10_12[var13_15 * 2 + 1];
                    var10_12[var13_15 * 2 + 1] = var15_17;
                    var15_17 = this.ac[var14_16];
                    this.ac[var14_16] = this.ac[var13_15];
                    this.ac[var13_15] = var15_17;
                }
                ++var14_16;
            }
            ++var13_15;
        }
        var14_16 = 0;
        while (var14_16 < this.aI.length) {
            var15_17 = 0;
            while (var15_17 < this.aI.length) {
                if (this.be[var14_16 * 2] == var10_12[var15_17 * 2] && this.be[var14_16 * 2 + 1] == var10_12[var15_17 * 2 + 1]) {
                    this.aI[var14_16] = var15_17;
                    break;
                }
                ++var15_17;
            }
            ++var14_16;
        }
        this.b = this.a((DataInputStream)var1_1);
        this.bb = this.a((DataInputStream)var1_1);
        this.h = this.a((DataInputStream)var1_1);
        this.bO = this.a((DataInputStream)var1_1);
        this.ai = this.a((DataInputStream)var1_1);
        this.p = this.a((DataInputStream)var1_1);
        try {
            if (var1_1 == null) return;
            var1_1.close();
            return;
        }
        catch (Exception var18_18) {
            // empty catch block
        }
    }

    public byte[] a(DataInputStream dataInputStream) throws Exception {
        byte by = dataInputStream.readByte();
        byte[] byArray = new byte[by];
        int n = 0;
        while (n < byArray.length) {
            byArray[n] = dataInputStream.readByte();
            ++n;
        }
        return byArray;
    }

    public void a(DataInputStream dataInputStream, int[] nArray, byte[] byArray) throws Exception {
        int n = 0;
        while (n < nArray.length) {
            nArray[n] = dataInputStream.readByte() * 100;
            ++n;
        }
        int n2 = 0;
        while (n2 < byArray.length) {
            byArray[n2] = dataInputStream.readByte();
            ++n2;
        }
    }

    public void a(Graphics graphics, int n, int n2, int n3, int n4, int n5) {
        int n6;
        int n7;
        int n8 = n5 / 2;
        int n9 = n5 - n8;
        int n10 = 0;
        while (n10 < n8) {
            n7 = com.nokia.mid.appl.disco.b.g(n, n + n3);
            n6 = com.nokia.mid.appl.disco.b.g(n2, n2 + n4);
            this.a(graphics, n7, n6, 4);
            ++n10;
        }
        n7 = 0;
        while (n7 < n9) {
            n6 = com.nokia.mid.appl.disco.b.g(n, n + n3);
            int n11 = com.nokia.mid.appl.disco.b.g(n2, n2 + n4);
            this.a(graphics, n6, n11, 5);
            ++n7;
        }
    }

    public void hideNotify() {
        boolean bl = !this.aO;
        this.aO = false;
        super.hideNotify();
        if (bl) {
            this.i(0);
        }
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void e() {
        try {
            block9: {
                var1_1 = RecordStore.openRecordStore((String)"DISCO", (boolean)true);
                if (var1_1.getNumRecords() == 0) break block9;
                var2_3 = var1_1.getRecord(1);
                var3_4 = null;
                try {
                    var3_4 = new DataInputStream(new ByteArrayInputStream(var2_3));
                    this.O = var3_4.readBoolean();
                    this.av = false;
                    if (this.O) {
                        this.av = true;
                    }
                    if (var3_4 == null) ** GOTO lbl24
                    ** GOTO lbl23
                }
                catch (Exception var4_5) {
                    block10: {
                        block11: {
                            var4_5.printStackTrace();
                            if (var3_4 == null) break block10;
                            break block11;
                            catch (Throwable var5_6) {
                                if (var3_4 != null) {
                                    var3_4.close();
                                }
                                var3_4 = null;
                                throw var5_6;
                            }
lbl23:
                            // 1 sources

                            var3_4.close();
lbl24:
                            // 2 sources

                            var3_4 = null;
                        }
                        var3_4.close();
                    }
                    var3_4 = null;
                }
            }
            var1_1.closeRecordStore();
            return;
        }
        catch (Exception var1_2) {
            // empty catch block
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void I() {
        try {
            block19: {
                block18: {
                    var1_1 = RecordStore.openRecordStore((String)"DISCO", (boolean)true);
                    if (var1_1.getNumRecords() == 0) break block19;
                    var2_3 = var1_1.getRecord(1);
                    var3_4 = null;
                    try {
                        var3_4 = new DataInputStream(new ByteArrayInputStream(var2_3));
                        var4_5 = var3_4.readBoolean();
                        if (!var4_5) break block18;
                        this.O = true;
                        this.bu = var3_4.readInt();
                        this.o = var3_4.readInt();
                        this.at = var3_4.readInt();
                        this.m = var3_4.readInt();
                        this.a = var3_4.readInt();
                        this.ar = var3_4.readInt();
                        this.k = var3_4.readInt();
                        this.bD = var3_4.readInt();
                        this.L = var3_4.readInt();
                        this.bf = var3_4.readInt();
                        this.G = var3_4.readInt();
                        this.K = var3_4.readInt();
                        this.bn = var3_4.readInt();
                        this.aF = var3_4.readInt();
                        this.as = var3_4.readInt();
                        this.aS = var3_4.readInt();
                        this.aX = var3_4.readInt();
                        this.al = var3_4.readInt();
                        this.U = var3_4.readInt();
                        this.aP = var3_4.readInt();
                        this.I = var3_4.readInt();
                        var5_7 = 0;
                        if (true) ** GOTO lbl49
                    }
                    catch (Exception var4_6) {
                        var4_6.printStackTrace();
                        if (var3_4 != null) {
                            var3_4.close();
                        }
                        var3_4 = null;
                        try {
                            break block19;
                        }
                        catch (Throwable var13_15) {
                            if (var3_4 != null) {
                                var3_4.close();
                            }
                            var3_4 = null;
                            throw var13_15;
                        }
                    }
                    do {
                        this.aa[var5_7] = var3_4.readInt();
                        ++var5_7;
lbl49:
                        // 2 sources

                    } while (var5_7 < this.aa.length);
                    var6_8 = 0;
                    while (var6_8 < this.aB.length) {
                        this.aB[var6_8] = var3_4.readInt();
                        ++var6_8;
                    }
                    var7_9 = 0;
                    while (var7_9 < this.bp.length) {
                        this.bp[var7_9] = var3_4.readInt();
                        ++var7_9;
                    }
                    var8_10 = 0;
                    while (var8_10 < this.bH.length) {
                        this.bH[var8_10] = var3_4.readInt();
                        ++var8_10;
                    }
                    var9_11 = 0;
                    while (var9_11 < this.u.length) {
                        this.u[var9_11] = var3_4.readInt();
                        ++var9_11;
                    }
                    var10_12 = 0;
                    while (var10_12 < this.p.length) {
                        this.p[var10_12] = var3_4.readByte();
                        ++var10_12;
                    }
                    this.ap = var3_4.readBoolean();
                    this.aO = var3_4.readBoolean();
                    this.ag = var3_4.readBoolean();
                    this.aL = var3_4.readBoolean();
                    this.bd = var3_4.readBoolean();
                    this.bs.z = var3_4.readInt();
                    this.bs.y = var3_4.readInt();
                    this.bs.s = var3_4.readInt();
                    this.bs.o = var3_4.readInt();
                    this.bs.q = var3_4.readInt();
                    this.bs.m = var3_4.readInt();
                    this.bs.w = var3_4.readInt();
                    this.bs.l = var3_4.readInt();
                    this.bs.f = var3_4.readInt();
                    this.bs.u = var3_4.readInt();
                    this.bs.d = var3_4.readInt();
                    this.bs.p = var3_4.readInt();
                    this.bs.r = var3_4.readInt();
                    this.bs.k = var3_4.readInt();
                    this.bs.v = var3_4.readInt();
                    this.bs.t = var3_4.readInt();
                    this.bs.c = var3_4.readInt();
                    this.bs.A = var3_4.readInt();
                    this.bs.b = var3_4.readInt();
                    var11_13 = 0;
                    while (var11_13 < this.bs.a.length) {
                        this.bs.a[var11_13] = var3_4.readInt();
                        ++var11_13;
                    }
                    var12_14 = 0;
                    while (var12_14 < this.bs.i.length) {
                        this.bs.i[var12_14] = var3_4.readInt();
                        ++var12_14;
                    }
                    this.bs.n = var3_4.readBoolean();
                    this.bs.e = var3_4.readBoolean();
                    this.bs.j = var3_4.readBoolean();
                    this.bs.x = var3_4.readLong();
                    this.bs.g = var3_4.readLong();
                    this.bs.h = var3_4.readLong();
                }
                if (var3_4 != null) {
                    var3_4.close();
                }
                var3_4 = null;
            }
            var1_1.closeRecordStore();
            return;
        }
        catch (Exception var1_2) {
            var1_2.printStackTrace();
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void z() {
        try {
            block21: {
                block20: {
                    var1_1 = RecordStore.openRecordStore((String)"DISCO", (boolean)true);
                    var2_3 = null;
                    var3_4 = null;
                    try {
                        var3_4 = new ByteArrayOutputStream();
                        var4_5 = new DataOutputStream(var3_4);
                        var4_5.writeBoolean(this.O);
                        if (!this.O) break block20;
                        var4_5.writeInt(this.bu);
                        var4_5.writeInt(this.o);
                        var4_5.writeInt(this.at);
                        var4_5.writeInt(this.m);
                        var4_5.writeInt(this.a);
                        var4_5.writeInt(this.ar);
                        var4_5.writeInt(this.k);
                        var4_5.writeInt(this.bD);
                        var4_5.writeInt(this.L);
                        var4_5.writeInt(this.bf);
                        var4_5.writeInt(this.G);
                        var4_5.writeInt(this.K);
                        var4_5.writeInt(this.bn);
                        var4_5.writeInt(this.aF);
                        var4_5.writeInt(this.as);
                        var4_5.writeInt(this.aS);
                        var4_5.writeInt(this.aX);
                        var4_5.writeInt(this.al);
                        var4_5.writeInt(this.U);
                        var4_5.writeInt(this.aP);
                        var4_5.writeInt(this.I);
                        var5_7 = 0;
                        if (true) ** GOTO lbl48
                    }
                    catch (Exception var4_6) {
                        var4_6.printStackTrace();
                        if (var3_4 != null) {
                            var3_4.close();
                        }
                        var3_4 = null;
                        try {
                            break block21;
                        }
                        catch (Throwable var13_15) {
                            if (var3_4 != null) {
                                var3_4.close();
                            }
                            var3_4 = null;
                            throw var13_15;
                        }
                    }
                    do {
                        var4_5.writeInt(this.aa[var5_7]);
                        ++var5_7;
lbl48:
                        // 2 sources

                    } while (var5_7 < this.aa.length);
                    var6_8 = 0;
                    while (var6_8 < this.aB.length) {
                        var4_5.writeInt(this.aB[var6_8]);
                        ++var6_8;
                    }
                    var7_9 = 0;
                    while (var7_9 < this.bp.length) {
                        var4_5.writeInt(this.bp[var7_9]);
                        ++var7_9;
                    }
                    var8_10 = 0;
                    while (var8_10 < this.bH.length) {
                        var4_5.writeInt(this.bH[var8_10]);
                        ++var8_10;
                    }
                    var9_11 = 0;
                    while (var9_11 < this.u.length) {
                        var4_5.writeInt(this.u[var9_11]);
                        ++var9_11;
                    }
                    var10_12 = 0;
                    while (var10_12 < this.p.length) {
                        var4_5.writeByte(this.p[var10_12]);
                        ++var10_12;
                    }
                    var4_5.writeBoolean(this.ap);
                    var4_5.writeBoolean(this.aO);
                    var4_5.writeBoolean(this.ag);
                    var4_5.writeBoolean(this.aL);
                    var4_5.writeBoolean(this.bd);
                    var4_5.writeInt(this.bs.z);
                    var4_5.writeInt(this.bs.y);
                    var4_5.writeInt(this.bs.s);
                    var4_5.writeInt(this.bs.o);
                    var4_5.writeInt(this.bs.q);
                    var4_5.writeInt(this.bs.m);
                    var4_5.writeInt(this.bs.w);
                    var4_5.writeInt(this.bs.l);
                    var4_5.writeInt(this.bs.f);
                    var4_5.writeInt(this.bs.u);
                    var4_5.writeInt(this.bs.d);
                    var4_5.writeInt(this.bs.p);
                    var4_5.writeInt(this.bs.r);
                    var4_5.writeInt(this.bs.k);
                    var4_5.writeInt(this.bs.v);
                    var4_5.writeInt(this.bs.t);
                    var4_5.writeInt(this.bs.c);
                    var4_5.writeInt(this.bs.A);
                    var4_5.writeInt(this.bs.b);
                    var11_13 = 0;
                    while (var11_13 < this.bs.a.length) {
                        var4_5.writeInt(this.bs.a[var11_13]);
                        ++var11_13;
                    }
                    var12_14 = 0;
                    while (var12_14 < this.bs.i.length) {
                        var4_5.writeInt(this.bs.i[var12_14]);
                        ++var12_14;
                    }
                    var4_5.writeBoolean(this.bs.n);
                    var4_5.writeBoolean(this.bs.e);
                    var4_5.writeBoolean(this.bs.j);
                    var4_5.writeLong(this.bs.x);
                    var4_5.writeLong(this.bs.g);
                    var4_5.writeLong(this.bs.h);
                }
                var2_3 = var3_4.toByteArray();
                if (var3_4 != null) {
                    var3_4.close();
                }
                var3_4 = null;
            }
            if (var1_1.getNumRecords() == 0) {
                var1_1.addRecord(var2_3, 0, var2_3.length);
            } else {
                var1_1.setRecord(1, var2_3, 0, var2_3.length);
            }
            var1_1.closeRecordStore();
            return;
        }
        catch (Exception var1_2) {
            var1_2.printStackTrace();
        }
    }
}

