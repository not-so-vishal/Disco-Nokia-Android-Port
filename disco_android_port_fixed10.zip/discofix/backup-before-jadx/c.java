/*
 * Decompiled with CFR 0.152.
 */
package com.nokia.mid.appl.disco;

import java.io.DataInputStream;
import java.io.InputStream;

public class c {
    private static c a = null;
    public static final String b = System.getProperty("microedition.locale");

    private c() {
    }

    private static String a(String string, String string2, String string3) {
        int n = string.indexOf(string2);
        return n >= 0 ? string.substring(0, n) + string3 + string.substring(n + string2.length()) : string;
    }

    public static synchronized String a(int n) {
        return c.a(n, null);
    }

    public static synchronized String a(int n, String[] stringArray) {
        try {
            InputStream inputStream;
            if (a == null) {
                a = new c();
            }
            if ((inputStream = a.getClass().getResourceAsStream("/lang." + b)) == null) {
                inputStream = a.getClass().getResourceAsStream("/lang.xx");
            }
            if (inputStream == null) {
                return "NoLang";
            }
            DataInputStream dataInputStream = new DataInputStream(inputStream);
            dataInputStream.skipBytes(n * 2);
            short s = dataInputStream.readShort();
            dataInputStream.skipBytes(s - n * 2 - 2);
            String string = dataInputStream.readUTF();
            dataInputStream.close();
            if (stringArray != null) {
                if (stringArray.length == 1) {
                    string = c.a(string, "%U", stringArray[0]);
                } else {
                    int n2 = 0;
                    while (n2 < stringArray.length) {
                        string = c.a(string, "%" + n2 + "U", stringArray[n2]);
                        ++n2;
                    }
                }
            }
            return string;
        }
        catch (Exception exception) {
            return "Err";
        }
    }
}

