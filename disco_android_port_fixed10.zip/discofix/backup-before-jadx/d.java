/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nokia.mid.ui.DeviceControl
 *  javax.microedition.lcdui.Command
 *  javax.microedition.lcdui.CommandListener
 *  javax.microedition.lcdui.Display
 *  javax.microedition.lcdui.Displayable
 *  javax.microedition.lcdui.Form
 *  javax.microedition.lcdui.Graphics
 *  javax.microedition.lcdui.Image
 *  javax.microedition.lcdui.Item
 *  javax.microedition.lcdui.List
 *  javax.microedition.lcdui.StringItem
 *  javax.microedition.midlet.MIDlet
 */
package com.nokia.mid.appl.disco;

import com.nokia.mid.appl.disco.c;
import com.nokia.mid.appl.disco.e;
import com.nokia.mid.ui.DeviceControl;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.Item;
import javax.microedition.lcdui.List;
import javax.microedition.lcdui.StringItem;
import javax.microedition.midlet.MIDlet;

public class d
extends e {
    private Image e;
    private Form h;
    private boolean c;
    private Displayable d;
    private int k;
    private int a = 0;
    private List b;
    private int l = 0;

    public int e() {
        return this.l;
    }

    private void d() {
        if (this.k == 1) {
            this.k = 0;
            this.b = new List(com.nokia.mid.appl.disco.c.a(111), 3);
            int n = 0;
            while (n <= com.nokia.mid.appl.disco.e.aY[0]) {
                this.b.append(com.nokia.mid.appl.disco.c.a(41, new String[]{"" + (n + 1)}), null);
                ++n;
            }
            this.b.addCommand(com.nokia.mid.appl.disco.e.bK);
            this.b.setCommandListener((CommandListener)this);
            Display display = Display.getDisplay((MIDlet)this.bq);
            this.d = display.getCurrent();
            display.setCurrent((Displayable)this.b);
        } else {
            this.bq.a(this.k == 1);
            this.c = true;
            this.k = 0;
        }
    }

    public synchronized void commandAction(Command command, Displayable displayable) {
        super.commandAction(command, displayable);
        if (displayable == this.b) {
            Display display = Display.getDisplay((MIDlet)this.bq);
            if (command == com.nokia.mid.appl.disco.e.bK) {
                this.l = 0;
                if (this.d != null) {
                    display.setCurrent(this.d);
                } else {
                    display.setCurrent((Displayable)this);
                }
                this.d = null;
            } else {
                this.l = this.b.getSelectedIndex();
            }
            this.b.removeCommand(com.nokia.mid.appl.disco.e.bK);
            this.b.setCommandListener(null);
            this.b = null;
            if (command != com.nokia.mid.appl.disco.e.bK) {
                this.c = true;
                this.bq.a(true);
            }
        } else if (command == com.nokia.mid.appl.disco.e.bx) {
            this.bq.c();
        } else if (displayable == this.h && command == com.nokia.mid.appl.disco.e.bK) {
            Display display = Display.getDisplay((MIDlet)this.bq);
            if (this.d == this) {
                this.a = 100000;
            }
            display.setCurrent(this.d);
            this.d = null;
            while (this.h.size() > 0) {
                this.h.delete(0);
            }
        } else if (command == com.nokia.mid.appl.disco.e.j) {
            this.k = 1;
            this.d();
        } else if (command == com.nokia.mid.appl.disco.e.aG) {
            this.k = 2;
            this.d();
        } else if (command == com.nokia.mid.appl.disco.e.z) {
            this.h.setTitle(com.nokia.mid.appl.disco.c.a(40));
            this.h.append(com.nokia.mid.appl.disco.c.a(0));
            Display display = Display.getDisplay((MIDlet)this.bq);
            this.d = display.getCurrent();
            display.setCurrent((Displayable)this.h);
        } else if (command == com.nokia.mid.appl.disco.e.i) {
            Display display = Display.getDisplay((MIDlet)this.bq);
            this.a(display.getCurrent());
        }
    }

    private void a(Displayable displayable) {
        this.h.setTitle(com.nokia.mid.appl.disco.c.a(30));
        if (com.nokia.mid.appl.disco.e.bL != null) {
            int n = 0;
            n = 0;
            while (n < 3) {
                int n2 = 0;
                while (n2 < 1) {
                    this.h.append((Item)new StringItem(com.nokia.mid.appl.disco.e.bL[n][n2], "" + com.nokia.mid.appl.disco.e.ay[n][n2]));
                    ++n2;
                }
                ++n;
            }
        }
        this.d = displayable;
        Display display = Display.getDisplay((MIDlet)this.bq);
        display.setCurrent((Displayable)this.h);
    }

    public void b() throws Exception {
        super.b();
        try {
            this.e = Image.createImage((String)"/title.png");
        }
        catch (Exception exception) {
            // empty catch block
        }
        this.E = false;
        this.h = new Form("");
        this.h.addCommand(com.nokia.mid.appl.disco.e.bK);
        this.h.setCommandListener((CommandListener)this);
    }

    public void a() {
        this.k = 0;
        this.c = false;
        DeviceControl.setLights((int)0, (int)100);
        super.a();
    }

    public void a(int n, int n2) {
        try {
            this.a += n;
            if (this.a + n >= 5000 && this.a <= 5000) {
                this.i(0);
            }
            switch (this.k) {
                case 1: 
                case 2: {
                    break;
                }
                default: {
                    Thread.sleep(10L);
                    break;
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public void a(Graphics graphics) {
        graphics.setColor(0, 0, 0);
        graphics.fillRect(0, 0, this.getWidth(), this.getHeight());
        this.b(graphics);
    }

    private void b(Graphics graphics) {
        if (this.e == null) {
            return;
        }
        int n = (this.getWidth() - 128) / 2;
        int n2 = (this.getHeight() - 128) / 2;
        int n3 = n + (128 - this.e.getWidth()) / 2;
        int n4 = n2 + (128 - this.e.getHeight()) / 2;
        graphics.drawImage(this.e, n3, n4, 20);
    }

    public void f(int n, int n2) {
        this.i(0);
    }

    public void J() {
        super.J();
        this.a = 100000;
        this.e = null;
    }

    public boolean c() {
        return this.c;
    }
}

