/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.microedition.lcdui.Display
 *  javax.microedition.lcdui.Displayable
 *  javax.microedition.midlet.MIDlet
 */
package com.nokia.mid.appl.disco;

import com.nokia.mid.appl.disco.b;
import com.nokia.mid.appl.disco.d;
import com.nokia.mid.appl.disco.e;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.midlet.MIDlet;

public class GameMIDlet
extends MIDlet
implements Runnable {
    private Display a;
    private b h;
    private d g;
    private boolean d = true;
    private int i = -1;
    private boolean c = false;
    private boolean b = false;
    private boolean e;
    private Thread j;
    private int f = -1;
    private boolean k = false;

    public GameMIDlet() {
        try {
            this.h = new b();
            this.h.a(this);
            this.h.b();
            this.a = Display.getDisplay((MIDlet)this);
            this.g = new d();
            this.g.a(this);
            this.g.b();
            this.g.setCommandListener(this.g);
            this.h.setCommandListener(this.g);
            com.nokia.mid.appl.disco.e.a(this.h.u());
        }
        catch (Exception exception) {
            exception.printStackTrace();
            this.notifyDestroyed();
        }
    }

    public void startApp() {
        try {
            if (this.d) {
                this.g.a();
                this.a.setCurrent((Displayable)this.g);
                this.f = -1;
                this.i = 0;
            } else if (this.i == 0) {
                this.g.h();
            } else {
                this.h.h();
            }
            this.j = new Thread(this);
            this.j.start();
        }
        catch (Exception exception) {
            exception.printStackTrace();
            this.notifyDestroyed();
        }
    }

    public void pauseApp() {
        if (this.i == 0) {
            this.g.w();
        } else {
            this.h.w();
        }
    }

    public void destroyApp(boolean bl) {
        this.c = true;
        try {
            if (this.j != null) {
                this.k = true;
                this.j.join();
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public void a(boolean bl) {
        this.e = bl;
        this.f = 1;
    }

    private void b() {
        if (this.i == 0) {
            return;
        }
        this.i = 0;
        boolean bl = false;
        if (this.h.f() && !this.h.u()) {
            this.h.J();
            com.nokia.mid.appl.disco.e.a(false);
        } else if (!this.h.o()) {
            this.h.w();
            com.nokia.mid.appl.disco.e.a(this.h.u());
        } else {
            com.nokia.mid.appl.disco.e.a(this.h.u());
        }
        this.g.a();
        this.g.i(0);
    }

    private void a() {
        switch (this.f) {
            case 1: {
                this.d();
                break;
            }
            case 0: {
                this.b();
            }
        }
        this.f = -1;
    }

    public void c() {
        this.c = true;
    }

    private void d() {
        com.nokia.mid.appl.disco.e.a(true);
        this.g.J();
        this.i = 1;
        if (this.e) {
            if (!this.h.f() && !this.d) {
                this.h.J();
            }
            this.h.repaint();
            this.h.d(this.g.e());
            this.h.a();
            this.a.setCurrent((Displayable)this.h);
        } else {
            if (this.h.f()) {
                this.h.d(this.g.e());
                this.h.a();
            } else {
                this.h.h();
            }
            this.a.setCurrent((Displayable)this.h);
        }
        this.d = false;
    }

    public void run() {
        boolean bl = this.h.u();
        while (!this.b) {
            boolean bl2 = false;
            if (this.i == 0) {
                this.g.D();
                bl2 = this.g.c();
                if (bl2 && this.f == -1) {
                    this.f = 1;
                }
            } else if (this.i == 1) {
                this.h.D();
                bl2 = this.h.f();
                if (bl2 && this.f == -1) {
                    this.f = 0;
                }
            }
            if (bl2 || this.f != -1) {
                this.a();
            } else if (bl != this.h.u()) {
                bl = this.h.u();
                com.nokia.mid.appl.disco.e.a(bl);
            }
            if (!this.c) continue;
            if (this.i == 0) {
                this.g.J();
            } else {
                this.h.J();
            }
            this.b = true;
        }
        this.h.l();
        this.g.l();
        if (!this.k) {
            this.notifyDestroyed();
        }
    }
}

