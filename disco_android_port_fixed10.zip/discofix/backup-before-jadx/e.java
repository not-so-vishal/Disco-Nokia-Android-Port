/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nokia.mid.ui.FullCanvas
 *  javax.microedition.lcdui.Command
 *  javax.microedition.lcdui.CommandListener
 *  javax.microedition.lcdui.Display
 *  javax.microedition.lcdui.Displayable
 *  javax.microedition.lcdui.Graphics
 *  javax.microedition.lcdui.Image
 *  javax.microedition.lcdui.List
 *  javax.microedition.midlet.MIDlet
 *  javax.microedition.rms.RecordStore
 */
package com.nokia.mid.appl.disco;

import com.nokia.mid.appl.disco.GameMIDlet;
import com.nokia.mid.appl.disco.c;
import com.nokia.mid.ui.FullCanvas;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.Vector;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.List;
import javax.microedition.midlet.MIDlet;
import javax.microedition.rms.RecordStore;

public class e
extends FullCanvas
implements CommandListener {
    private boolean ao = true;
    protected GameMIDlet bq;
    boolean aK = false;
    private int[] bk = new int[5];
    int aQ = 20;
    private int bI;
    private int aA = 20;
    private int q = 500;
    int Z;
    static Command j;
    static Command aG;
    static Command z;
    static Command bx;
    static Command bK;
    static Command i;
    static byte[] aY;
    static boolean S;
    private List x;
    private Vector n;
    private Command ah;
    private CommandListener g;
    boolean E = true;
    private Image V;
    long f;
    int W;
    static int bl;
    static int M;
    static boolean bM;
    static String[][] bL;
    static int[][] ay;

    public void a(GameMIDlet gameMIDlet) {
        this.bq = gameMIDlet;
    }

    public void b() throws Exception {
        this.ah = new Command(c.a(17), 2, 2);
        this.x = new List(c.a(52), 3);
        this.x.setCommandListener((CommandListener)this);
        this.n = new Vector();
        if (bL == null) {
            try {
                e.a(null, "", -1, 3, 1, true);
                int n = 0;
                while (n < 3) {
                    e.a(n, c.a(41, new String[]{"" + (n + 1)}), 0);
                    ++n;
                }
            }
            catch (Throwable throwable) {
                bL = null;
            }
        }
        if (j == null) {
            try {
                RecordStore recordStore = RecordStore.openRecordStore((String)"AppData", (boolean)true);
                if (recordStore.getNumRecords() == 0) {
                    int n = recordStore.addRecord(aY, 0, aY.length);
                } else {
                    aY = recordStore.getRecord(1);
                }
                recordStore.closeRecordStore();
                recordStore = null;
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
            bK = new Command(c.a(17), 2, 2);
            aG = new Command(c.a(23), 1, 1);
            j = new Command(c.a(53), 1, 2);
            i = new Command(c.a(30), 1, 3);
            z = new Command(c.a(40), 1, 5);
            bx = new Command(c.a(26), 7, 8);
        }
        this.addCommand(j);
        this.addCommand(z);
        this.addCommand(i);
        this.addCommand(bx);
        if (this.V == null) {
            this.V = Image.createImage((String)"/softkey.png");
        }
    }

    public void a(Graphics graphics) {
    }

    public void f(int n, int n2) {
    }

    public void e(int n, int n2) {
    }

    public void c(int n, int n2) {
    }

    public void a() {
        this.r();
        this.aK = true;
        this.ao = true;
        this.F();
        this.f = System.currentTimeMillis();
    }

    void F() {
        this.Z = 0;
        this.bI = 0;
        int n = this.bk.length - 1;
        while (n >= 0) {
            int n2 = n;
            while (n2 >= 0) {
                int n3 = n2--;
                this.bk[n3] = this.bk[n3] + this.aA;
            }
            --n;
        }
        this.aQ = this.aA;
        this.f = System.currentTimeMillis();
    }

    void b(int n) {
        if (n > this.q) {
            n = this.q;
        }
        this.Z += n;
        int n2 = 0;
        while (n2 < this.bk.length) {
            int n3 = n2++;
            this.bk[n3] = this.bk[n3] + n;
        }
        int n4 = this.bk[this.bI] / this.bk.length;
        this.bk[this.bI] = 0;
        ++this.bI;
        this.bI %= this.bk.length;
        this.aQ = n4;
    }

    public void w() {
        if (!this.ao) {
            this.ao = true;
        }
    }

    public void h() {
        if (this.ao) {
            this.ao = false;
            this.aK = true;
            this.r();
            this.F();
            this.f = System.currentTimeMillis();
        }
    }

    public void J() {
        this.aK = false;
        this.ao = false;
    }

    public void l() {
        this.k();
    }

    public void k() {
        try {
            RecordStore recordStore = RecordStore.openRecordStore((String)"AppData", (boolean)false);
            recordStore.setRecord(1, aY, 0, aY.length);
            recordStore.closeRecordStore();
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void a(int n, int n2) {
    }

    public boolean o() {
        return this.ao;
    }

    public void paint(Graphics graphics) {
        if (this.aK) {
            this.a(graphics);
        } else {
            if (Display.getDisplay((MIDlet)this.bq).isColor()) {
                graphics.setColor(0, 0, 0);
            } else {
                graphics.setColor(255, 255, 255);
            }
            graphics.fillRect(0, 0, this.getWidth(), this.getHeight());
        }
        if (this.E) {
            graphics.setClip(0, 0, this.getWidth(), this.getHeight());
            graphics.drawImage(this.V, 2, this.getHeight() - 1, 36);
        }
    }

    protected void keyPressed(int n) {
        if (n == -7) {
            this.i(0);
        } else {
            this.f(n, this.getGameAction(n));
        }
    }

    protected void keyReleased(int n) {
        if (n != -6 && n != -7 && n != -5) {
            this.e(n, this.getGameAction(n));
        }
    }

    protected void keyRepeated(int n) {
        if (n != -6 && n != -7 && n != -5) {
            this.c(n, this.getGameAction(n));
        }
    }

    public void hideNotify() {
        if (this.aK && !this.o()) {
            this.w();
        }
    }

    public void showNotify() {
        if (this.aK && this.o()) {
            this.h();
        }
    }

    public void D() {
        try {
            if (!this.o()) {
                long l = System.currentTimeMillis();
                int n = (int)(l - this.f);
                this.b(n);
                this.f = l;
                this.a(this.aQ, this.Z);
                Display display = Display.getDisplay((MIDlet)this.bq);
                if (display.getCurrent() == this) {
                    this.repaint();
                    this.serviceRepaints();
                }
            }
            Thread.sleep(1L);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    void r() {
        this.removeCommand(aG);
        if (S) {
            this.addCommand(aG);
        }
    }

    public static void a(boolean bl) {
        S = bl;
    }

    public void addCommand(Command command) {
        if (command == bx) {
            this.x.addCommand(bx);
        } else if (!this.n.contains(command)) {
            int n = -1;
            int n2 = 0;
            while (n2 < this.n.size()) {
                Command command2 = (Command)this.n.elementAt(n2);
                if (command2.getPriority() > command.getPriority()) {
                    n = n2;
                    break;
                }
                ++n2;
            }
            if (n == -1) {
                this.n.addElement(command);
            } else {
                this.n.insertElementAt(command, n);
            }
        }
    }

    public void removeCommand(Command command) {
        if (command == bx) {
            this.x.removeCommand(bx);
        } else {
            this.n.removeElement(command);
        }
    }

    public void setCommandListener(CommandListener commandListener) {
        this.g = commandListener;
    }

    public void i(int n) {
        Display display = Display.getDisplay((MIDlet)this.bq);
        if (display.getCurrent() == this.x) {
            return;
        }
        this.r();
        if (this.x.size() > 0) {
            while (this.x.size() > 0) {
                this.x.delete(0);
            }
        }
        int n2 = 0;
        while (n2 < this.n.size()) {
            this.x.append(((Command)this.n.elementAt(n2)).getLabel(), null);
            ++n2;
        }
        if (this.x.size() > n) {
            this.x.setSelectedIndex(n, true);
        }
        display.setCurrent((Displayable)this.x);
    }

    public void E() {
    }

    public void commandAction(Command command, Displayable displayable) {
        if (displayable == this.x && command == List.SELECT_COMMAND || command == this.ah || command == bx) {
            if (command != this.ah) {
                if (command == bx) {
                    this.bq.c();
                } else {
                    this.W = this.x.getSelectedIndex();
                    this.g.commandAction((Command)this.n.elementAt(this.x.getSelectedIndex()), (Displayable)this);
                }
            } else {
                this.E();
                Display display = Display.getDisplay((MIDlet)this.bq);
                display.setCurrent((Displayable)this);
                while (this.x.size() > 0) {
                    this.x.delete(0);
                }
            }
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void a(String var0, String var1_1, int var2_2, int var3_3, int var4_4, boolean var5_5) throws Exception {
        block19: {
            block18: {
                var6_6 = null;
                var7_7 = false;
                try {
                    var6_6 = RecordStore.openRecordStore((String)"HighScores", (boolean)true);
                }
                catch (Exception var8_8) {
                    RecordStore.deleteRecordStore((String)"HighScores");
                    var6_6 = RecordStore.openRecordStore((String)"HighScores", (boolean)true);
                    var7_7 = true;
                }
                if (var6_6.getNumRecords() == 0) break block19;
                var8_9 = var6_6.getRecord(1);
                var9_11 = null;
                try {
                    var9_11 = new DataInputStream(new ByteArrayInputStream(var8_9));
                    var10_14 = var9_11.readByte();
                    var11_16 = var9_11.readByte();
                    var12_17 = var9_11.readBoolean();
                    if (var10_14 != var3_3 || var11_16 != var4_4 || var5_5 != var12_17) {
                        var9_11.close();
                        var9_11 = null;
                        var6_6.closeRecordStore();
                        RecordStore.deleteRecordStore((String)"HighScores");
                        var6_6 = RecordStore.openRecordStore((String)"HighScores", (boolean)true);
                        var7_7 = true;
                        break block18;
                    }
                    e.bL = new String[var3_3][];
                    e.ay = new int[var3_3][];
                    var13_18 = 0;
                    if (true) ** GOTO lbl55
                }
                catch (Exception var10_15) {
                    var6_6.closeRecordStore();
                    RecordStore.deleteRecordStore((String)"HighScores");
                    var6_6 = RecordStore.openRecordStore((String)"HighScores", (boolean)true);
                    var7_7 = true;
                    if (var9_11 != null) {
                        var9_11.close();
                    }
                    var9_11 = null;
                    try {
                        break block19;
                    }
                    catch (Throwable var15_20) {
                        if (var9_11 != null) {
                            var9_11.close();
                        }
                        var9_11 = null;
                        throw var15_20;
                    }
                }
                do {
                    e.bL[var13_18] = new String[var4_4];
                    e.ay[var13_18] = new int[var4_4];
                    var14_19 = 0;
                    while (var14_19 < var4_4) {
                        e.bL[var13_18][var14_19] = var9_11.readUTF();
                        e.ay[var13_18][var14_19] = var9_11.readInt();
                        ++var14_19;
                    }
                    ++var13_18;
lbl55:
                    // 2 sources

                } while (var13_18 < var3_3);
                var9_11.close();
                var9_11 = null;
            }
            if (var9_11 != null) {
                var9_11.close();
            }
            var9_11 = null;
        }
        if (var6_6.getNumRecords() == 0 || var7_7) {
            e.bL = new String[var3_3][];
            e.ay = new int[var3_3][];
            var8_10 = 0;
            block9: while (true) {
                if (var8_10 >= var3_3) {
                    var9_13 = e.G();
                    var6_6.addRecord(var9_13, 0, var9_13.length);
                    break;
                }
                e.bL[var8_10] = new String[var4_4];
                e.ay[var8_10] = new int[var4_4];
                var9_12 = 0;
                while (true) {
                    if (var9_12 >= var4_4) {
                        ++var8_10;
                        continue block9;
                    }
                    e.bL[var8_10][var9_12] = var1_1;
                    e.ay[var8_10][var9_12] = var2_2;
                    ++var9_12;
                }
                break;
            }
        }
        var6_6.closeRecordStore();
        e.bl = var3_3;
        e.M = var4_4;
        e.bM = var5_5;
    }

    public static void g() throws Exception {
        RecordStore recordStore = RecordStore.openRecordStore((String)"HighScores", (boolean)true);
        byte[] byArray = e.G();
        recordStore.setRecord(1, byArray, 0, byArray.length);
        recordStore.closeRecordStore();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static byte[] G() throws Exception {
        var0 = null;
        var1_1 = null;
        try {
            var1_1 = new ByteArrayOutputStream();
            var2_2 = new DataOutputStream(var1_1);
            var2_2.writeByte(e.bl);
            var2_2.writeByte(e.M);
            var2_2.writeBoolean(e.bM);
            var3_4 = 0;
            if (true) ** GOTO lbl21
            catch (Exception var2_3) {
                throw var2_3;
            }
            do {
                var4_5 = 0;
                while (var4_5 < e.M) {
                    var2_2.writeUTF(e.bL[var3_4][var4_5]);
                    var2_2.writeInt(e.ay[var3_4][var4_5]);
                    ++var4_5;
                }
                ++var3_4;
lbl21:
                // 2 sources

            } while (var3_4 < e.bl);
            var0 = var1_1.toByteArray();
            return var0;
        }
        finally {
            if (var1_1 != null) {
                var1_1.close();
            }
            var1_1 = null;
        }
    }

    /*
     * Unable to fully structure code
     */
    public static void a(int var0, String var1_1, int var2_2) {
        block7: {
            if (var1_1 == null || var1_1.equals("")) {
                var1_1 = " ";
            }
            var3_3 = e.M - 1;
            if (!e.bM) ** GOTO lbl10
            while (var3_3 >= 0 && var2_2 > e.ay[var0][var3_3]) {
                --var3_3;
            }
            break block7;
lbl-1000:
            // 1 sources

            {
                --var3_3;
lbl10:
                // 2 sources

                ** while (var3_3 >= 0 && var2_2 < e.ay[var0][var3_3])
            }
        }
        ++var3_3;
        var4_4 = e.M - 2;
        while (var4_4 >= var3_3) {
            e.bL[var0][var4_4 + 1] = e.bL[var0][var4_4];
            e.ay[var0][var4_4 + 1] = e.ay[var0][var4_4];
            --var4_4;
        }
        if (var3_3 < e.M) {
            e.bL[var0][var3_3] = var1_1;
            e.ay[var0][var3_3] = var2_2;
        }
        try {
            e.g();
        }
        catch (Exception var5_5) {
            // empty catch block
        }
    }

    static {
        aY = new byte[]{0};
        S = false;
    }
}

